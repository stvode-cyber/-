// BigInt 在 JSON.stringify 默认会抛错（"Do not know how to serialize a BigInt"）。
// 资产/采集源含 BigInt 字段（localMtime），统一在此转成字符串后再下发，避免列表/详情接口 500。
function safeStringify(value) {
    return JSON.stringify(value, (_k, v) => (typeof v === 'bigint' ? v.toString() : v));
}
export function success(res, data, message = 'success', code = 200) {
    const payload = {
        code,
        data,
        message,
        timestamp: Math.floor(Date.now() / 1000),
        requestId: res.locals.requestId || generateRequestId(),
    };
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    return res.send(safeStringify(payload));
}
export function fail(res, message, code = 400, data = null) {
    const payload = {
        code,
        data,
        message,
        timestamp: Math.floor(Date.now() / 1000),
        requestId: res.locals.requestId || generateRequestId(),
    };
    res.status(code >= 100 && code < 600 ? code : 400);
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    return res.send(safeStringify(payload));
}
export function generateRequestId() {
    return 'req_' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}
export class HttpError extends Error {
    code;
    constructor(message, code = 400) {
        super(message);
        this.code = code;
    }
}
//# sourceMappingURL=response.js.map