import jwt from 'jsonwebtoken';
import { prisma } from '../lib/prisma.js';
import { fail } from '../utils/response.js';
const JWT_PUBLIC_KEY = process.env.JWT_PUBLIC_KEY;
export async function gatewayAuth(req, res, next) {
    if (!JWT_PUBLIC_KEY) {
        return fail(res, '网关未配置验证公钥', 500);
    }
    let token;
    const header = req.headers.authorization;
    if (header && header.startsWith('Bearer ')) {
        token = header.slice(7);
    }
    if (!token) {
        const cookies = req.headers.cookie || '';
        const match = /(?:^|;\s*)aie_token=([^;]+)/.exec(cookies);
        if (match)
            token = decodeURIComponent(match[1]);
    }
    if (!token) {
        return fail(res, '未授权：缺少访问令牌', 401);
    }
    let decoded;
    try {
        decoded = jwt.verify(token, JWT_PUBLIC_KEY, { algorithms: ['RS256'] });
    }
    catch {
        return fail(res, '令牌无效或已过期', 401);
    }
    // 订阅控权：校验用户存在且已开通 AI
    try {
        const user = await prisma.user.findUnique({
            where: { id: decoded.userId },
            select: { id: true, aiEnabled: true, aiExpiresAt: true },
        });
        if (!user) {
            return fail(res, '用户不存在，请重新注册登录', 401);
        }
        if (!user.aiEnabled) {
            return fail(res, 'AI 服务未开通，请联系管理员', 403);
        }
        if (user.aiExpiresAt && user.aiExpiresAt.getTime() < Date.now()) {
            return fail(res, 'AI 服务已到期，请联系管理员续费', 403);
        }
    }
    catch {
        // DB 异常：fail-open（放行），避免云端库抖动导致全站 502
    }
    req.user = {
        userId: decoded.userId,
        username: decoded.username || '',
        role: decoded.role || 'user',
    };
    next();
}
//# sourceMappingURL=gatewayAuth.js.map