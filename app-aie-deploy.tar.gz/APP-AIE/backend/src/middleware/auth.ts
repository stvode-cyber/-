import type { Request, Response, NextFunction } from 'express'
import jwt from 'jsonwebtoken'
import { fail } from '../utils/response.js'

export interface JwtPayload {
  userId: string
  username: string
  role: string
}

// 扩展 Express Request 类型
declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: JwtPayload
    }
  }
}

/**
 * JWT 密钥：缺失时启动即失败，杜绝默认值被攻击者利用伪造任意 token
 * - 生产环境务必通过环境变量注入强随机字符串（至少 32 位）
 * - 使用中间变量 + 显式类型注解，确保闭包内调用时类型为 string（避免 string | undefined 收窄失效）
 */
const JWT_SECRET_RAW = process.env.JWT_SECRET
if (!JWT_SECRET_RAW) {
  throw new Error('[启动失败] 缺少环境变量 JWT_SECRET，请在 .env 中配置强随机密钥（至少 32 位）')
}
const JWT_SECRET: string = JWT_SECRET_RAW
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d'

export function authRequired(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization
  if (!header || !header.startsWith('Bearer ')) {
    return fail(res, '未授权：缺少访问令牌', 401)
  }
  const token = header.slice(7)
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as JwtPayload
    req.user = decoded
    next()
  } catch {
    return fail(res, '令牌无效或已过期，请重新登录', 401)
  }
}

export function adminRequired(req: Request, res: Response, next: NextFunction) {
  if (!req.user || req.user.role !== 'admin') {
    return fail(res, '权限不足：需要管理员权限', 403)
  }
  next()
}

export function signToken(payload: JwtPayload): string {
  return jwt.sign(payload, JWT_SECRET, {
    expiresIn: JWT_EXPIRES_IN,
  } as jwt.SignOptions)
}
