import type { Response } from 'express'

export interface ApiResponse<T = unknown> {
  code: number
  data: T | null
  message: string
  timestamp: number
  requestId: string
}

export function success<T>(res: Response, data: T, message = 'success', code = 200) {
  const payload: ApiResponse<T> = {
    code,
    data,
    message,
    timestamp: Math.floor(Date.now() / 1000),
    requestId: res.locals.requestId || generateRequestId(),
  }
  return res.json(payload)
}

export function fail(res: Response, message: string, code = 400, data: unknown = null) {
  const payload: ApiResponse = {
    code,
    data,
    message,
    timestamp: Math.floor(Date.now() / 1000),
    requestId: res.locals.requestId || generateRequestId(),
  }
  return res.status(code >= 100 && code < 600 ? code : 400).json(payload)
}

export function generateRequestId(): string {
  return 'req_' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
}

export class HttpError extends Error {
  code: number
  constructor(message: string, code = 400) {
    super(message)
    this.code = code
  }
}
