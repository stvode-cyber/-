import { PrismaClient } from '@prisma/client'

/**
 * Prisma 客户端单例
 *
 * 为什么用全局单例：
 * - 开发环境下 tsx watch 会热重载，每次重载会重新 import 模块
 * - 如果不缓存到 globalThis，会创建多个 PrismaClient 实例
 * - 多个实例会导致连接池耗尽、日志重复打印、事务冲突等问题
 *
 * 日志级别：
 * - 开发环境：warn + error
 * - 生产环境：error
 */
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient }

export const prisma = globalForPrisma.prisma ?? new PrismaClient({
  log: process.env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
})

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prisma
}
