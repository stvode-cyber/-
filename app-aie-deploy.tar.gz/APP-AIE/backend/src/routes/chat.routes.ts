import { Router } from 'express'
import { z } from 'zod'
import { prisma } from '../lib/prisma.js'
import { success, HttpError } from '../utils/response.js'
import { authRequired } from '../middleware/auth.js'
import { rateLimit } from '../middleware/rateLimit.js'
import { generateReply } from '../lib/ai-reply.js'
import { auditReq } from '../utils/audit.js'

const router = Router()
router.use(authRequired)

/** DG-02 多模态消息单条数据上限（base64 字符数）：图片 5MB / 文件 5MB / 位置无附件 */
const MAX_MEDIA_BASE64_SIZE = 5 * 1024 * 1024

/** 多模态消息发送速率限制：每用户每分钟最多 10 次（含 base64 上传，防滥用） */
const multimodalRateLimit = rateLimit({
  limit: 10,
  windowMs: 60_000,
  keyFn: (req) => `mm:${req.user!.userId}`,
})

/**
 * DG-02 多模态消息发送 schema
 * - image:    content=描述/caption, mediaUrl=data URL, metadata={width,height}
 * - file:     content=文件名,        mediaUrl=data URL, metadata={fileName,fileSize,fileType}
 * - location: content=地址文本,      mediaUrl=null,      metadata={lat,lng,address}
 */
const multimodalSchema = z.object({
  messageType: z.enum(['image', 'file', 'location']),
  content: z.string().max(500).optional(),
  mediaUrl: z.string().max(MAX_MEDIA_BASE64_SIZE).optional(),
  metadata: z.record(z.unknown()).optional(),
})

/** 会话列表 */
router.get('/sessions', async (req, res, next) => {
  try {
    const sessions = await prisma.chatSession.findMany({
      where: { userId: req.user!.userId },
      orderBy: { updatedAt: 'desc' },
      take: 50,
      include: { _count: { select: { messages: true } } },
    })
    return success(res, sessions)
  } catch (e) {
    next(e)
  }
})

/**
 * 创建会话
 * - 写入台账：chat.session_create
 */
router.post('/sessions', async (req, res, next) => {
  try {
    const session = await prisma.chatSession.create({
      data: {
        userId: req.user!.userId,
        title: req.body.title || '新对话',
      },
    })
    auditReq(req, res, {
      category: 'chat',
      action: 'session_create',
      targetType: 'ChatSession',
      targetId: session.id,
      summary: `创建对话: ${session.title}`,
    })
    return success(res, session, '已创建', 201)
  } catch (e) {
    next(e)
  }
})

/** 会话消息列表 */
router.get('/sessions/:id/messages', async (req, res, next) => {
  try {
    const id = req.params.id
    const session = await prisma.chatSession.findUnique({ where: { id } })
    if (!session || session.userId !== req.user!.userId) {
      throw new HttpError('会话不存在', 404)
    }
    const messages = await prisma.message.findMany({
      where: { sessionId: id },
      orderBy: { createdAt: 'asc' },
    })
    return success(res, messages)
  } catch (e) {
    next(e)
  }
})

/**
 * 发送消息（同步返回AI回复）
 * - 保存用户消息
 * - 调用 generateReply 生成 AI 回复（基于规则）
 * - 写入台账：chat.message_send（含 messageType）
 */
router.post('/sessions/:id/messages', async (req, res, next) => {
  try {
    const id = req.params.id
    const session = await prisma.chatSession.findUnique({ where: { id } })
    if (!session || session.userId !== req.user!.userId) {
      throw new HttpError('会话不存在', 404)
    }
    const content = (req.body.content || '').toString().trim()
    if (!content) throw new HttpError('消息不能为空', 422)

    // 保存用户消息
    await prisma.message.create({
      data: { sessionId: id, userId: req.user!.userId, role: 'user', content },
    })

    // 生成 AI 回复（基于规则）
    const { reply, messageType, metadata } = await generateReply(content, req.user!.userId)

    const aiMsg = await prisma.message.create({
      data: {
        sessionId: id,
        userId: req.user!.userId,
        role: 'assistant',
        content: reply,
        messageType,
        metadata: metadata ? JSON.stringify(metadata) : null,
      },
    })

    await prisma.chatSession.update({ where: { id }, data: { updatedAt: new Date() } })

    // 台账：发送消息
    auditReq(req, res, {
      category: 'chat',
      action: 'message_send',
      targetType: 'Message',
      targetId: aiMsg.id,
      summary: `对话: ${content.slice(0, 30)} → ${messageType}`,
      detail: { userMsg: content, aiMessageType: messageType },
    })

    // DG-16 危机干预信号：单独审计到 crisis 类别，标记高优先级
    // 不记录用户原始消息全文（隐私保护），仅记录触发等级和回复卡片类型
    if (messageType === 'crisis_card') {
      const crisisMeta = metadata as { crisis?: { level?: string } } | undefined
      auditReq(req, res, {
        category: 'crisis',
        action: 'intervention_triggered',
        targetType: 'Message',
        targetId: aiMsg.id,
        summary: `危机干预触发: ${crisisMeta?.crisis?.level || 'unknown'}`,
        detail: {
          level: crisisMeta?.crisis?.level || 'unknown',
          contentLen: content.length,
          // 仅记录前 10 字符用于核对，避免完整隐私暴露
          contentPreview: content.slice(0, 10),
        },
      })
    }

    return success(res, aiMsg, 'success', 201)
  } catch (e) {
    next(e)
  }
})

/**
 * 反馈（like / dislike）
 * - 写入台账：chat.feedback
 */
router.post('/messages/:id/feedback', async (req, res, next) => {
  try {
    const id = req.params.id
    const feedback = req.body.feedback
    if (!['like', 'dislike'].includes(feedback)) {
      throw new HttpError('反馈类型错误', 422)
    }
    const msg = await prisma.message.findUnique({ where: { id } })
    if (!msg || msg.userId !== req.user!.userId) {
      throw new HttpError('消息不存在', 404)
    }
    await prisma.message.update({ where: { id }, data: { feedback } })
    auditReq(req, res, {
      category: 'chat',
      action: 'feedback',
      targetType: 'Message',
      targetId: id,
      summary: `消息反馈: ${feedback}`,
    })
    return success(res, null, '已反馈')
  } catch (e) {
    next(e)
  }
})

/**
 * DG-02 多模态消息发送（图片/文件/位置）
 *
 * 与文本消息端点的差异：
 * - 不走 generateReply（多模态内容超出文本规则匹配能力）
 * - AI 回复固定为"已收到附件"的确认 + 触发后续动作建议
 * - 多模态消息同样审计，category=chat，action=multimodal_send
 *
 * 字段约束：
 * - image:    mediaUrl 必填（data URL），content 可选（描述），metadata 含 width/height
 * - file:     mediaUrl 必填（data URL），content=文件名，metadata 含 fileName/fileSize/fileType
 * - location: mediaUrl 留空，content=地址文本，metadata 含 lat/lng/address
 */
router.post('/sessions/:id/messages/multimodal', multimodalRateLimit, async (req, res, next) => {
  try {
    const id = req.params.id
    const session = await prisma.chatSession.findUnique({ where: { id } })
    if (!session || session.userId !== req.user!.userId) {
      throw new HttpError('会话不存在', 404)
    }

    const body = multimodalSchema.parse(req.body)
    const { messageType, mediaUrl, metadata } = body

    // 各类型校验
    if (messageType === 'image' || messageType === 'file') {
      if (!mediaUrl) throw new HttpError(`${messageType} 消息必须包含 mediaUrl`, 422)
      if (mediaUrl.length > MAX_MEDIA_BASE64_SIZE) {
        throw new HttpError(
          `附件过大（上限 ${Math.floor(MAX_MEDIA_BASE64_SIZE / 1024 / 1024)}MB）`,
          413,
        )
      }
    }
    if (messageType === 'location' && !metadata?.lat && metadata?.lat !== 0) {
      throw new HttpError('位置消息必须包含 lat/lng', 422)
    }

    const content = body.content?.trim() || (messageType === 'image' ? '[图片]' : messageType === 'file' ? '[文件]' : '[位置]')

    // 保存用户多模态消息
    await prisma.message.create({
      data: {
        sessionId: id,
        userId: req.user!.userId,
        role: 'user',
        content,
        messageType,
        mediaUrl: mediaUrl || null,
        metadata: metadata ? JSON.stringify(metadata) : null,
      },
    })

    // AI 确认回复（基于类型给出差异化建议）
    const replyMap: Record<string, string> = {
      image: '📷 收到你的图片。你可以告诉我图片内容，我会帮你整理为笔记或转为碎片记录。',
      file: '📎 收到文件。如果需要归档，可以告诉我文件用途，我会建议归档分类或转为碎片。',
      location: '📍 收到你的位置。如果需要在此安排事项，可以让我创建提醒或任务。',
    }
    const reply = replyMap[messageType]
    const aiMsg = await prisma.message.create({
      data: {
        sessionId: id,
        userId: req.user!.userId,
        role: 'assistant',
        content: reply,
        messageType: 'text',
      },
    })

    await prisma.chatSession.update({ where: { id }, data: { updatedAt: new Date() } })

    auditReq(req, res, {
      category: 'chat',
      action: 'multimodal_send',
      targetType: 'Message',
      targetId: aiMsg.id,
      summary: `多模态消息: ${messageType} · ${content.slice(0, 30)}`,
      detail: {
        messageType,
        contentLen: content.length,
        hasMedia: !!mediaUrl,
        mediaSize: mediaUrl ? mediaUrl.length : 0,
      },
    })

    return success(res, aiMsg, '已发送', 201)
  } catch (e) {
    next(e)
  }
})

export default router
