import { Router } from 'express'
import bcrypt from 'bcryptjs'
import { z } from 'zod'
import { prisma } from '../lib/prisma.js'
import { success, HttpError } from '../utils/response.js'
import { authRequired, signToken } from '../middleware/auth.js'
import { auditReq, auditReqAsync } from '../utils/audit.js'
import { rateLimit } from '../middleware/rateLimit.js'

const router = Router()

// 登录/注册接口频率限制：每 IP 每分钟 10 次，防暴破
const authRateLimit = rateLimit({ limit: 10, windowMs: 60_000 })

const registerSchema = z.object({
  username: z.string().min(3).max(20),
  password: z.string().min(6).max(32),
  nickname: z.string().optional(),
})

/**
 * 用户注册
 * - 校验用户名唯一性
 * - 密码 bcrypt 加盐哈希
 * - 自动创建空钱包
 * - 写入台账：register
 */
router.post('/register', authRateLimit, async (req, res, next) => {
  try {
    const parsed = registerSchema.safeParse(req.body)
    if (!parsed.success) {
      throw new HttpError(parsed.error.issues[0]?.message || '参数错误', 422)
    }
    const { username, password, nickname } = parsed.data

    const exists = await prisma.user.findUnique({ where: { username } })
    if (exists) throw new HttpError('用户名已存在', 409)

    const hashed = await bcrypt.hash(password, 10)
    const user = await prisma.user.create({
      data: {
        username,
        password: hashed,
        nickname: nickname || username,
        wallet: { create: { balance: 0 } },
      },
      select: { id: true, username: true, nickname: true, role: true },
    })

    const token = signToken({
      userId: user.id,
      username: user.username,
      role: user.role,
    })

    // 台账：注册（关键审计，await 确保落库）
    await auditReqAsync(req, res, {
      userId: user.id,
      username: user.username,
      category: 'auth',
      action: 'register',
      targetType: 'User',
      targetId: user.id,
      summary: `新用户注册: ${user.username}`,
      detail: { username, nickname },
    })

    return success(res, { token, user }, '注册成功')
  } catch (e) {
    next(e)
  }
})

const loginSchema = z.object({
  username: z.string(),
  password: z.string(),
})

/**
 * 用户登录
 * - 用户名 + 密码
 * - 登录成功后更新 lastLoginAt
 * - 写入台账：login（无论成功失败都记录，便于追踪异常登录）
 */
router.post('/login', authRateLimit, async (req, res, next) => {
  try {
    const parsed = loginSchema.safeParse(req.body)
    if (!parsed.success) throw new HttpError('用户名或密码错误', 422)
    const { username, password } = parsed.data

    const user = await prisma.user.findUnique({ where: { username } })
    if (!user) {
      // 台账：登录失败（关键审计，await 确保落库）
      await auditReqAsync(req, res, {
        username,
        category: 'auth',
        action: 'login',
        summary: `登录失败（用户不存在）: ${username}`,
        result: 'fail',
        detail: { reason: 'user_not_found' },
      })
      throw new HttpError('用户名或密码错误', 401)
    }

    const ok = await bcrypt.compare(password, user.password)
    if (!ok) {
      // 台账：登录失败（关键审计，await 确保落库）
      await auditReqAsync(req, res, {
        userId: user.id,
        username: user.username,
        category: 'auth',
        action: 'login',
        summary: `登录失败（密码错误）: ${user.username}`,
        result: 'fail',
        detail: { reason: 'wrong_password' },
      })
      throw new HttpError('用户名或密码错误', 401)
    }

    await prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    })

    const token = signToken({
      userId: user.id,
      username: user.username,
      role: user.role,
    })

    // 台账：登录成功（关键审计，await 确保落库）
    await auditReqAsync(req, res, {
      userId: user.id,
      username: user.username,
      category: 'auth',
      action: 'login',
      summary: `用户登录: ${user.username}`,
    })

    return success(res, {
      token,
      user: {
        id: user.id,
        username: user.username,
        nickname: user.nickname,
        avatar: user.avatar,
        role: user.role,
        onboarded: user.onboarded,
        preferredTone: user.preferredTone,
      },
    }, '登录成功')
  } catch (e) {
    next(e)
  }
})

// 获取当前用户
router.get('/me', authRequired, async (req, res, next) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user!.userId },
      select: {
        id: true, username: true, nickname: true, avatar: true,
        role: true, onboarded: true, preferredTone: true, primaryGoal: true,
        email: true, phone: true, lastLoginAt: true, createdAt: true,
      },
    })
    if (!user) throw new HttpError('用户不存在', 404)
    return success(res, user)
  } catch (e) {
    next(e)
  }
})

/** 冷启动画像 schema */
const onboardingSchema = z.object({
  primaryGoal: z.string(),
  preferredTone: z.string(),
  favoriteFood: z.string().optional(),
})

/**
 * 冷启动画像采集
 * - 用户首次登录后填写：本周目标、语气偏好、最想吃的食物
 * - 写入台账：auth.onboarding
 */
router.post('/onboarding', authRequired, async (req, res, next) => {
  try {
    const parsed = onboardingSchema.safeParse(req.body)
    if (!parsed.success) throw new HttpError('参数错误', 422)
    const { primaryGoal, preferredTone } = parsed.data

    const user = await prisma.user.update({
      where: { id: req.user!.userId },
      data: { primaryGoal, preferredTone, onboarded: true },
      select: { id: true, onboarded: true, preferredTone: true, primaryGoal: true },
    })
    auditReq(req, res, {
      category: 'auth',
      action: 'onboarding',
      targetType: 'User',
      targetId: user.id,
      summary: `冷启动画像: 目标=${primaryGoal}, 语气=${preferredTone}`,
      detail: { primaryGoal, preferredTone },
    })
    return success(res, user, '画像已保存')
  } catch (e) {
    next(e)
  }
})

/** 更新个人资料 Schema（所有字段可选） */
const updateProfileSchema = z.object({
  nickname: z.string().min(1, '昵称不能为空').max(20, '昵称不能超过 20 字').optional(),
  avatar: z.string().max(10, '头像内容过长').optional(), // emoji 或短字符串
  preferredTone: z.string().optional(), // 语气模式 key
  primaryGoal: z.string().max(50, '本周目标不能超过 50 字').optional().nullable(),
})

/**
 * 更新个人资料
 * - 支持更新昵称、头像、语气偏好、本周目标
 * - 不允许更新 username / password / role（敏感字段）
 * - 写入台账：auth.update_profile
 */
router.patch('/me', authRequired, async (req, res, next) => {
  try {
    const parsed = updateProfileSchema.safeParse(req.body)
    if (!parsed.success) throw new HttpError(parsed.error.issues[0]?.message || '参数错误', 422)
    const data = parsed.data

    // 过滤掉 undefined 字段，避免误清空
    const updateData: Record<string, unknown> = {}
    if (data.nickname !== undefined) updateData.nickname = data.nickname
    if (data.avatar !== undefined) updateData.avatar = data.avatar
    if (data.preferredTone !== undefined) updateData.preferredTone = data.preferredTone
    if (data.primaryGoal !== undefined) updateData.primaryGoal = data.primaryGoal

    if (Object.keys(updateData).length === 0) {
      throw new HttpError('没有可更新的字段', 422)
    }

    const user = await prisma.user.update({
      where: { id: req.user!.userId },
      data: updateData,
      select: {
        id: true, username: true, nickname: true, avatar: true,
        role: true, onboarded: true, preferredTone: true, primaryGoal: true,
      },
    })

    auditReq(req, res, {
      category: 'auth',
      action: 'update_profile',
      targetType: 'User',
      targetId: user.id,
      summary: `更新个人资料: ${Object.keys(updateData).join(', ')}`,
      detail: updateData,
    })

    return success(res, user, '资料已更新')
  } catch (e) {
    next(e)
  }
})

export default router
