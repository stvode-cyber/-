import { Router } from 'express'
import { z } from 'zod'
import { prisma } from '../lib/prisma.js'
import { success, HttpError } from '../utils/response.js'
import { authRequired } from '../middleware/auth.js'
import { auditReq } from '../utils/audit.js'

const router = Router()
router.use(authRequired)

const submitSchema = z.object({
  realName: z.string().min(2, '姓名至少 2 个字符').max(30),
  idCard: z.string().regex(/^\d{17}[\dXx]$/, '身份证号格式无效（应为 18 位）'),
  phone: z.string().optional(),
})

/**
 * 身份证号脱敏：保留前 6 后 4，中间用 * 替换
 * 例：110101199001011234 → 110101********1234
 */
function maskIdCard(idCard: string): string {
  if (idCard.length !== 18) return idCard
  return idCard.slice(0, 6) + '********' + idCard.slice(-4)
}

/** 查询当前用户认证状态 + 历史记录 */
router.get('/status', async (req, res, next) => {
  try {
    const [user, records] = await Promise.all([
      prisma.user.findUnique({
        where: { id: req.user!.userId },
        select: { verifyLevel: true, username: true, nickname: true, phone: true, email: true },
      }),
      prisma.realName.findMany({
        where: { userId: req.user!.userId },
        orderBy: { submittedAt: 'desc' },
      }),
    ])

    if (!user) throw new HttpError('用户不存在', 404)

    // 脱敏身份证号后返回
    const maskedRecords = records.map((r) => ({
      ...r,
      idCard: maskIdCard(r.idCard),
    }))

    return success(res, {
      verifyLevel: user.verifyLevel,
      profile: {
        username: user.username,
        nickname: user.nickname,
        phone: user.phone,
        email: user.email,
      },
      records: maskedRecords,
      // 当前是否有 pending 审核中
      hasPending: records.some((r) => r.status === 'pending'),
    })
  } catch (e) {
    next(e)
  }
})

/**
 * 提交实名认证申请
 * - 同一时间只允许一条 pending，若已有 pending 则提示等待审核
 * - 已通过认证（Lv2+）不允许重复提交
 * - 写入台账：verify.submit
 */
router.post('/submit', async (req, res, next) => {
  try {
    const parsed = submitSchema.safeParse(req.body)
    if (!parsed.success) throw new HttpError(parsed.error.issues[0]?.message || '参数错误', 422)
    const data = parsed.data

    // 检查用户当前认证等级
    const user = await prisma.user.findUnique({
      where: { id: req.user!.userId },
      select: { verifyLevel: true },
    })
    if (!user) throw new HttpError('用户不存在', 404)
    if (user.verifyLevel !== 'Lv0') {
      throw new HttpError(`当前已认证（${user.verifyLevel}），无需重复提交`, 400)
    }

    // 检查是否已有 pending
    const pending = await prisma.realName.findFirst({
      where: { userId: req.user!.userId, status: 'pending' },
    })
    if (pending) {
      throw new HttpError('已有审核中的认证申请，请等待审核结果', 400)
    }

    const record = await prisma.realName.create({
      data: {
        userId: req.user!.userId,
        realName: data.realName,
        idCard: data.idCard.toUpperCase(),
        phone: data.phone,
      },
    })

    auditReq(req, res, {
      category: 'verify',
      action: 'submit',
      targetType: 'RealName',
      targetId: record.id,
      summary: `提交实名认证: ${data.realName} (${maskIdCard(data.idCard)})`,
      detail: { realName: data.realName, idCardMasked: maskIdCard(data.idCard) },
    })

    return success(res, record, '已提交，等待审核', 201)
  } catch (e) {
    next(e)
  }
})

export default router
