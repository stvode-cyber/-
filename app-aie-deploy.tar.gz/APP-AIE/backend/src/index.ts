import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import morgan from 'morgan'

import { requestId, notFound, errorHandler } from './middleware/error.js'
import { timing } from './middleware/timing.js'
import authRoutes from './routes/auth.routes.js'
import workRoutes from './routes/work.routes.js'
import lifeRoutes from './routes/life.routes.js'
import sleepRoutes from './routes/sleep.routes.js'
import verifyRoutes from './routes/verify.routes.js'
import financeRoutes from './routes/finance.routes.js'
import walletRoutes from './routes/wallet.routes.js'
import chatRoutes from './routes/chat.routes.js'
import reminderRoutes from './routes/reminder.routes.js'
import homeRoutes from './routes/home.routes.js'
import handoverRoutes from './routes/handover.routes.js'
import communityRoutes from './routes/community.routes.js'
import searchRoutes from './routes/search.routes.js'
import adminRoutes from './routes/admin.routes.js'
import fragmentRoutes from './routes/fragment.routes.js'
import manualEventRoutes from './routes/manual-event.routes.js'
import voiceMemoRoutes from './routes/voice-memo.routes.js'

const app = express()

app.use(cors({ origin: process.env.CORS_ORIGIN || 'http://localhost:5173', credentials: true }))
app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ extended: true }))
app.use(morgan('dev'))
// 请求 ID + 耗时统计（注入 res.locals.requestId / startTime，供台账读取）
app.use(requestId)
app.use(timing)

// 健康检查
app.get('/health', (_req, res) => res.json({ status: 'ok', ts: Date.now() }))

// 路由挂载
app.use('/api/v1/auth', authRoutes)
app.use('/api/v1/work', workRoutes)
app.use('/api/v1/life', lifeRoutes)
app.use('/api/v1/sleep', sleepRoutes)
app.use('/api/v1/verify', verifyRoutes)
app.use('/api/v1/finance', financeRoutes)
app.use('/api/v1/wallet', walletRoutes)
app.use('/api/v1/chat', chatRoutes)
app.use('/api/v1/reminder', reminderRoutes)
app.use('/api/v1/home', homeRoutes)
app.use('/api/v1/handover', handoverRoutes)
app.use('/api/v1/community', communityRoutes)
app.use('/api/v1/search', searchRoutes)
app.use('/api/v1/admin', adminRoutes)
app.use('/api/v1/fragment', fragmentRoutes)
app.use('/api/v1/manual-events', manualEventRoutes)
app.use('/api/v1/voice-memos', voiceMemoRoutes)

app.use(notFound)
app.use(errorHandler)

const PORT = Number(process.env.PORT) || 3001

app.listen(PORT, () => {
  console.log(`\n🚀 AI助理后端已启动`)
  console.log(`   本地地址: http://localhost:${PORT}`)
  console.log(`   健康检查: http://localhost:${PORT}/health\n`)
})
