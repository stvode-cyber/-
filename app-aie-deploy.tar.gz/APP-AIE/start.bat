@echo off
chcp 65001 >nul

echo ============================================================
echo   AI助理系统 - 启动服务
echo ============================================================
echo.
echo  正在启动后端 (http://localhost:3001)...
start "AIE-Backend" cmd /k "cd /d %~dp0backend && npm run dev"

echo  等待后端就绪...
timeout /t 3 /nobreak >nul

echo  正在启动前端 (http://localhost:5173)...
start "AIE-Frontend" cmd /k "cd /d %~dp0frontend && npm run dev"

echo.
echo ============================================================
echo   服务已启动！
echo.
echo   前端:  http://localhost:5173
echo   后端:  http://localhost:3001
echo.
echo   演示账号：
echo     普通用户:  demo / 123456
echo     管理员:    admin / admin123 (访问 /admin)
echo.
echo   关闭服务：直接关闭弹出的两个命令行窗口
echo ============================================================
echo.
echo  浏览器将自动打开...
timeout /t 2 /nobreak >nul
start http://localhost:5173
