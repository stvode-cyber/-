import { create } from 'zustand'
import { api, unwrap } from '../lib/api'

/**
 * 用户信息接口
 * - onboarded：是否完成冷启动画像采集
 * - preferredTone：AI 对话语气偏好（9种模式之一）
 * - primaryGoal：用户主目标（用于个性化推荐）
 */
export interface UserInfo {
  id: string
  username: string
  nickname?: string
  avatar?: string
  role: string
  onboarded: boolean
  preferredTone?: string
  primaryGoal?: string
}

/**
 * 全局认证状态（Zustand）
 * - 持久化策略：token + user 缓存在 localStorage，刷新页面后 init() 重新读取
 * - 401 响应在 api.ts 拦截器中统一处理，会清除缓存并跳转登录
 */
interface AuthState {
  user: UserInfo | null
  token: string | null
  loading: boolean
  init: () => void
  login: (username: string, password: string) => Promise<void>
  register: (username: string, password: string, nickname?: string) => Promise<void>
  logout: () => void
  refreshUser: () => Promise<void>
  setOnboarded: () => void
  /** 本地合并更新用户信息（同步到 localStorage） */
  updateUser: (patch: Partial<UserInfo>) => void
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  token: null,
  loading: true,

  /** 应用启动时调用：从 localStorage 恢复登录态 */
  init: () => {
    const token = localStorage.getItem('aie_token')
    const userStr = localStorage.getItem('aie_user')
    if (token && userStr) {
      try {
        const user = JSON.parse(userStr) as UserInfo
        set({ token, user, loading: false })
        return
      } catch {
        // ignore
      }
    }
    set({ token: null, user: null, loading: false })
  },

  /** 登录：成功后缓存 token + user */
  login: async (username, password) => {
    const res = await unwrap<{ token: string; user: UserInfo }>(
      api.post('/auth/login', { username, password }),
    )
    localStorage.setItem('aie_token', res.token)
    localStorage.setItem('aie_user', JSON.stringify(res.user))
    set({ token: res.token, user: res.user })
  },

  /** 注册：成功后等同于登录 */
  register: async (username, password, nickname) => {
    const res = await unwrap<{ token: string; user: UserInfo }>(
      api.post('/auth/register', { username, password, nickname }),
    )
    localStorage.setItem('aie_token', res.token)
    localStorage.setItem('aie_user', JSON.stringify(res.user))
    set({ token: res.token, user: res.user })
  },

  /** 登出：清缓存并跳转登录页 */
  logout: () => {
    localStorage.removeItem('aie_token')
    localStorage.removeItem('aie_user')
    set({ user: null, token: null })
    window.location.href = '/login'
  },

  /** 拉取最新用户信息（如冷启动完成后刷新 onboarded 字段） */
  refreshUser: async () => {
    const user = await unwrap<UserInfo>(api.get('/auth/me'))
    localStorage.setItem('aie_user', JSON.stringify(user))
    set({ user })
  },

  /** 冷启动完成标记（不立即请求后端，提交时由 OnboardingPage 调用 refreshUser） */
  setOnboarded: () => {
    set((state) => ({
      user: state.user ? { ...state.user, onboarded: true } : null,
    }))
  },

  /** 本地合并更新用户信息（同步到 localStorage，不请求后端） */
  updateUser: (patch) => {
    set((state) => {
      if (!state.user) return state
      const user = { ...state.user, ...patch }
      localStorage.setItem('aie_user', JSON.stringify(user))
      return { user }
    })
  },
}))
