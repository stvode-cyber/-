import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App.tsx'
import { ErrorBoundary } from './components/ErrorBoundary'
import './index.css'

/**
 * 应用入口
 *
 * - ErrorBoundary：全局错误边界，避免渲染异常导致整页白屏
 * - BrowserRouter：HTML5 history 路由
 * - StrictMode：开发环境严格模式（重复渲染检测副作用）
 */
ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ErrorBoundary>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </ErrorBoundary>
  </React.StrictMode>,
)
