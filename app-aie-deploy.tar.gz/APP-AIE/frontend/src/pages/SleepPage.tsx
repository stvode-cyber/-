import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Plus, Trash2, ChevronLeft, ChevronRight } from 'lucide-react'
import Header from '../components/Header'
import { api, unwrap } from '../lib/api'
import { useToast } from '../components/Toast'
import { formatDateTime, formatTime } from '../lib/utils'
import { LoadingState, ErrorState, EmptyState } from '../components/StateView'
import { useConfirm } from '../components/ConfirmDialog'
import { sleepQualityMeta, SLEEP_QUALITIES } from '../lib/constants'

interface Sleep {
  id: string
  sleepDate: string
  bedtime: string
  wakeTime: string
  durationMin: number
  quality?: number | null
  note?: string | null
}

interface WeeklyReport {
  range: { from: string; to: string }
  count: number
  avgDurationMin: number
  avgQuality: number
  sleepDebtMin: number
  records: Sleep[]
}

/**
 * 睡眠记录页 · 阶段二「睡眠分析」基础版
 *
 * 功能：
 * 1. 日期切换：上一日 / 下一日 / 回到今日
 * 2. 当日睡眠卡：入睡-起床时间、时长、质量评分、备注
 * 3. 周报卡：最近 7 天平均时长、平均质量、睡眠债务
 * 4. 新建/更新睡眠记录（底部弹层）：入睡/起床时间 + 质量 + 备注
 *
 * 数据来源：GET /sleep?date=  /  GET /sleep/weekly
 */
export default function SleepPage() {
  const toast = useToast((s) => s.show)
  const confirm = useConfirm()
  const [sleep, setSleep] = useState<Sleep | null>(null)
  const [weekly, setWeekly] = useState<WeeklyReport | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)
  const [showAdd, setShowAdd] = useState(false)
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10))
  const [searchParams, setSearchParams] = useSearchParams()

  useEffect(() => {
    load()
    if (searchParams.get('new') === '1') {
      setShowAdd(true)
      searchParams.delete('new')
      setSearchParams(searchParams, { replace: true })
    }
  }, [date])

  const load = async () => {
    setLoading(true)
    setError(false)
    try {
      const [s, w] = await Promise.all([
        unwrap<Sleep[]>(api.get(`/sleep?date=${date}`)),
        unwrap<WeeklyReport>(api.get('/sleep/weekly')),
      ])
      setSleep(s.length > 0 ? s[0] : null)
      setWeekly(w)
    } catch (err) {
      setError(true)
      toast((err as Error).message, 'error')
    } finally {
      setLoading(false)
    }
  }

  const remove = async (id: string) => {
    const ok = await confirm({
      title: '删除睡眠记录',
      message: '确定删除该条睡眠记录吗？此操作不可撤销。',
      confirmText: '删除',
      danger: true,
    })
    if (!ok) return
    try {
      await unwrap(api.delete(`/sleep/${id}`))
      toast('已删除', 'success')
      load()
    } catch (err) {
      toast((err as Error).message, 'error')
    }
  }

  const prevDay = () => {
    const d = new Date(date)
    d.setDate(d.getDate() - 1)
    setDate(d.toISOString().slice(0, 10))
  }
  const nextDay = () => {
    const d = new Date(date)
    d.setDate(d.getDate() + 1)
    setDate(d.toISOString().slice(0, 10))
  }
  const isToday = date === new Date().toISOString().slice(0, 10)
  const formatDateLabel = (d: string) => {
    const dt = new Date(d)
    return `${dt.getMonth() + 1}月${dt.getDate()}日`
  }

  /** 分钟 → "Xh Ymin" 简短格式 */
  const formatDuration = (min: number): string => {
    const h = Math.floor(min / 60)
    const m = min % 60
    return h > 0 ? `${h}h ${m}min` : `${m}min`
  }

  return (
    <div className="app-shell">
      <Header
        title="睡眠记录"
        right={
          <button onClick={() => setShowAdd(true)} className="p-2 text-primary-600">
            <Plus size={20} />
          </button>
        }
      />
      <div className="px-4 py-3 space-y-3">
        {/* 日期切换器 */}
        <div className="card flex items-center justify-between py-2">
          <button
            onClick={prevDay}
            className="p-2 rounded-lg hover:bg-gray-50 text-gray-500"
            aria-label="上一日"
          >
            <ChevronLeft size={18} />
          </button>
          <div className="text-center">
            <div className="text-sm font-medium text-gray-800">{formatDateLabel(date)}</div>
            {!isToday && (
              <button
                onClick={() => setDate(new Date().toISOString().slice(0, 10))}
                className="text-[10px] text-primary-500"
              >
                回到今日
              </button>
            )}
          </div>
          <button
            onClick={nextDay}
            disabled={isToday}
            className="p-2 rounded-lg hover:bg-gray-50 text-gray-500 disabled:opacity-30"
            aria-label="下一日"
          >
            <ChevronRight size={18} />
          </button>
        </div>

        {/* 周报卡 */}
        {weekly && weekly.count > 0 && (
          <div className="card bg-gradient-to-br from-indigo-50 to-white">
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-500">最近 7 天睡眠</div>
              <span className="text-xs text-gray-400">{weekly.count} 条记录</span>
            </div>
            <div className="grid grid-cols-3 gap-2 mt-2 text-center">
              <div>
                <div className="text-xs text-gray-400">日均时长</div>
                <div className="text-sm font-medium text-primary-600">
                  {formatDuration(weekly.avgDurationMin)}
                </div>
              </div>
              <div className="border-x border-gray-100">
                <div className="text-xs text-gray-400">平均质量</div>
                <div className="text-sm font-medium text-indigo-600">{weekly.avgQuality} / 5</div>
              </div>
              <div>
                <div className="text-xs text-gray-400">睡眠债务</div>
                <div className={`text-sm font-medium ${weekly.sleepDebtMin > 0 ? 'text-orange-500' : 'text-green-500'}`}>
                  {weekly.sleepDebtMin > 0 ? formatDuration(weekly.sleepDebtMin) : '无'}
                </div>
              </div>
            </div>
            {weekly.sleepDebtMin > 0 && (
              <div className="mt-2 text-xs text-orange-500">
                ⚠️ 累计缺觉 {formatDuration(weekly.sleepDebtMin)}，建议周末补眠或调整作息
              </div>
            )}
          </div>
        )}

        {/* 当日睡眠卡 / 列表 */}
        <div className="card">
          <div className="font-medium text-gray-800 mb-3">{formatDateLabel(date)} 睡眠</div>
          {loading ? (
            <LoadingState skeleton count={1} />
          ) : error ? (
            <ErrorState onRetry={load} />
          ) : !sleep ? (
            <EmptyState
              icon="😴"
              text={isToday ? '今日暂无睡眠记录' : '当日暂无睡眠记录'}
              hint={isToday ? '点击右上角 + 记录昨晚睡眠' : undefined}
            />
          ) : (
            <div className="space-y-3">
              {/* 主睡眠卡 */}
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-indigo-50 flex items-center justify-center text-xl">
                  😴
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm text-gray-800">
                      {formatTime(sleep.bedtime)} → {formatTime(sleep.wakeTime)}
                    </span>
                    <span className="badge bg-indigo-50 text-indigo-600">
                      {formatDuration(sleep.durationMin)}
                    </span>
                    {sleep.quality && (
                      <span className={`badge ${sleepQualityMeta[sleep.quality].color}`}>
                        {sleepQualityMeta[sleep.quality].emoji} {sleepQualityMeta[sleep.quality].label}
                      </span>
                    )}
                  </div>
                  {sleep.note && (
                    <div className="text-xs text-gray-500 mt-1">{sleep.note}</div>
                  )}
                  <div className="text-xs text-gray-400 mt-1">
                    🛏️ 入睡 {formatDateTime(sleep.bedtime)}
                  </div>
                </div>
                <button
                  onClick={() => remove(sleep.id)}
                  className="p-1.5 text-gray-300 hover:text-red-500 rounded"
                >
                  <Trash2 size={16} />
                </button>
              </div>

              {/* 时长解读 */}
              <div className="pt-3 border-t border-gray-100 text-xs text-gray-500">
                {sleep.durationMin < 360 && '⚠️ 睡眠不足 6 小时，建议早睡'}
                {sleep.durationMin >= 360 && sleep.durationMin < 480 && '✅ 睡眠时长合理（6-8 小时）'}
                {sleep.durationMin >= 480 && sleep.durationMin < 540 && '👍 睡眠充足（8-9 小时）'}
                {sleep.durationMin >= 540 && '💤 睡眠偏多（>9 小时），注意规律作息'}
              </div>
            </div>
          )}
        </div>
      </div>

      {showAdd && (
        <AddSleepModal
          onClose={() => setShowAdd(false)}
          onAdded={load}
          date={date}
          existing={sleep}
        />
      )}
    </div>
  )
}

function AddSleepModal({
  onClose,
  onAdded,
  date,
  existing,
}: {
  onClose: () => void
  onAdded: () => void
  date: string
  existing: Sleep | null
}) {
  const toast = useToast((s) => s.show)
  // 默认入睡时间：前一晚 23:00；起床时间：今日 07:00
  const defaultBedtime = (() => {
    const d = new Date(date)
    d.setDate(d.getDate() - 1)
    d.setHours(23, 0, 0, 0)
    return d.toISOString().slice(0, 16)
  })()
  const defaultWakeTime = (() => {
    const d = new Date(date)
    d.setHours(7, 0, 0, 0)
    return d.toISOString().slice(0, 16)
  })()

  const [bedtime, setBedtime] = useState(
    existing ? new Date(existing.bedtime).toISOString().slice(0, 16) : defaultBedtime,
  )
  const [wakeTime, setWakeTime] = useState(
    existing ? new Date(existing.wakeTime).toISOString().slice(0, 16) : defaultWakeTime,
  )
  const [quality, setQuality] = useState<number>(existing?.quality ?? 3)
  const [note, setNote] = useState(existing?.note || '')
  const [loading, setLoading] = useState(false)

  const submit = async () => {
    if (!bedtime || !wakeTime) {
      toast('请填写入睡和起床时间', 'error')
      return
    }
    setLoading(true)
    try {
      await unwrap(
        api.post('/sleep', {
          bedtime: new Date(bedtime).toISOString(),
          wakeTime: new Date(wakeTime).toISOString(),
          quality,
          note: note || undefined,
        }),
      )
      toast(existing ? '已更新' : '已记录', 'success')
      onAdded()
      onClose()
    } catch (err) {
      toast((err as Error).message, 'error')
    } finally {
      setLoading(false)
    }
  }

  /** 预估时长（仅展示，后端会精确计算） */
  const previewDuration = (() => {
    if (!bedtime || !wakeTime) return 0
    let b = new Date(bedtime).getTime()
    let w = new Date(wakeTime).getTime()
    if (w < b) w += 24 * 60 * 60 * 1000
    return Math.max(0, Math.round((w - b) / 60000))
  })()
  const formatDuration = (min: number): string => {
    const h = Math.floor(min / 60)
    const m = min % 60
    return h > 0 ? `${h}h ${m}min` : `${m}min`
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/40" />
      <div
        className="relative bg-white w-full max-w-[480px] mx-auto rounded-t-2xl p-5 animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="text-lg font-semibold mb-4">{existing ? '更新睡眠' : '记录睡眠'}</h3>
        <div className="space-y-3">
          <div>
            <label className="text-xs text-gray-500">入睡时间</label>
            <input
              type="datetime-local"
              className="input mt-1"
              value={bedtime}
              onChange={(e) => setBedtime(e.target.value)}
            />
          </div>
          <div>
            <label className="text-xs text-gray-500">起床时间</label>
            <input
              type="datetime-local"
              className="input mt-1"
              value={wakeTime}
              onChange={(e) => setWakeTime(e.target.value)}
            />
          </div>
          {previewDuration > 0 && (
            <div className="text-xs text-indigo-600 bg-indigo-50 rounded-lg px-3 py-2">
              😴 预估睡眠时长：<b>{formatDuration(previewDuration)}</b>
            </div>
          )}
          <div>
            <label className="text-xs text-gray-500">睡眠质量</label>
            <div className="grid grid-cols-5 gap-1.5 mt-1">
              {SLEEP_QUALITIES.map((q) => {
                const meta = sleepQualityMeta[q]
                return (
                  <button
                    key={q}
                    onClick={() => setQuality(q)}
                    className={`py-2 rounded-lg text-xs border flex flex-col items-center gap-0.5 ${
                      quality === q ? 'border-primary-500 bg-primary-50 text-primary-600' : 'border-gray-200 text-gray-600'
                    }`}
                  >
                    <span className="text-sm">{meta.emoji}</span>
                    <span>{meta.label}</span>
                  </button>
                )
              })}
            </div>
          </div>
          <input
            className="input"
            placeholder="备注（梦境/中断/感受，可选）"
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />
        </div>
        <div className="flex gap-2 mt-5">
          <button onClick={onClose} className="btn-secondary flex-1">取消</button>
          <button onClick={submit} disabled={loading} className="btn-primary flex-1 disabled:opacity-50">
            {loading ? '保存中...' : existing ? '更新' : '记录'}
          </button>
        </div>
      </div>
    </div>
  )
}
