import { Outlet, NavLink, useNavigate, Navigate } from 'react-router-dom'
import { LayoutDashboard, Users, LogOut, ScrollText, ClipboardList, MessageSquare, Loader2 } from 'lucide-react'
import { useAuthStore } from '../../stores/auth'
import { ConfirmDialog } from '../../components/ConfirmDialog'

export default function AdminLayout() {
  const { user, token, loading, logout } = useAuthStore()
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  // 初始化中：避免初始化期间闪现权限拦截页
  if (loading) {
    return (
      <div className="admin-shell flex items-center justify-center min-h-screen">
        <Loader2 size={24} className="animate-spin text-gray-400" />
      </div>
    )
  }

  // 未登录：跳转登录页，避免未登录用户看到后台界面结构
  if (!token || !user) {
    return <Navigate to="/login" replace />
  }

  // 已登录但非管理员：显示权限不足页
  if (user.role !== 'admin') {
    return (
      <div className="admin-shell flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="text-2xl mb-2">🚫</div>
          <div className="text-gray-600">权限不足</div>
          <button onClick={handleLogout} className="mt-4 btn-primary">返回登录</button>
        </div>
      </div>
    )
  }

  return (
    <div className="admin-shell flex min-h-screen">
      {/* 侧边栏 */}
      <aside className="w-56 bg-gray-900 text-white flex flex-col">
        <div className="p-5 border-b border-gray-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary-600 flex items-center justify-center font-bold">小</div>
            <div>
              <div className="font-semibold text-sm">AI小助</div>
              <div className="text-xs text-gray-400">管理后台</div>
            </div>
          </div>
        </div>
        <nav className="flex-1 py-4">
          <NavLink
            to="/admin"
            end
            className={({ isActive }) =>
              `flex items-center gap-3 px-5 py-3 text-sm transition-colors ${
                isActive ? 'bg-primary-600 text-white' : 'text-gray-300 hover:bg-gray-800'
              }`
            }
          >
            <LayoutDashboard size={18} />
            首页概览
          </NavLink>
          <NavLink
            to="/admin/users"
            className={({ isActive }) =>
              `flex items-center gap-3 px-5 py-3 text-sm transition-colors ${
                isActive ? 'bg-primary-600 text-white' : 'text-gray-300 hover:bg-gray-800'
              }`
            }
          >
            <Users size={18} />
            用户管理
          </NavLink>
          <NavLink
            to="/admin/audit-logs"
            className={({ isActive }) =>
              `flex items-center gap-3 px-5 py-3 text-sm transition-colors ${
                isActive ? 'bg-primary-600 text-white' : 'text-gray-300 hover:bg-gray-800'
              }`
            }
          >
            <ScrollText size={18} />
            台账日志
          </NavLink>
          <NavLink
            to="/admin/handovers"
            className={({ isActive }) =>
              `flex items-center gap-3 px-5 py-3 text-sm transition-colors ${
                isActive ? 'bg-primary-600 text-white' : 'text-gray-300 hover:bg-gray-800'
              }`
            }
          >
            <ClipboardList size={18} />
            交接单
          </NavLink>
          <NavLink
            to="/admin/community"
            className={({ isActive }) =>
              `flex items-center gap-3 px-5 py-3 text-sm transition-colors ${
                isActive ? 'bg-primary-600 text-white' : 'text-gray-300 hover:bg-gray-800'
              }`
            }
          >
            <MessageSquare size={18} />
            社区内容
          </NavLink>
        </nav>
        <div className="p-4 border-t border-gray-800">
          <div className="text-xs text-gray-400 mb-1">当前管理员</div>
          <div className="text-sm mb-3">{user?.username}</div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 text-xs text-gray-400 hover:text-white"
          >
            <LogOut size={14} /> 退出
          </button>
        </div>
      </aside>

      <main className="flex-1 bg-gray-50 overflow-auto">
        <Outlet />
      </main>
      <ConfirmDialog />
    </div>
  )
}
