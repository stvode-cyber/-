import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Plus, Check, Trash2 } from 'lucide-react'
import Header from '../components/Header'
import { api, unwrap } from '../lib/api'
import { useToast } from '../components/Toast'
import { formatDateTime } from '../lib/utils'
import { LoadingState, ErrorState, EmptyState } from '../components/StateView'
import { reminderLevelMeta, REMINDER_LEVELS } from '../lib/constants'

interface Reminder {
  id: string
  title: string
  content?: string
  level: string
  remindAt: string
  repeat: string
  done: boolean
}

type Tab = 'pending' | 'done' | 'all'
type LevelFilter = 'all' | typeof REMINDER_LEVELS[number]

/**
 * 提醒管理页
 *
 * 功能：
 * 1. Tab 切换：待办（默认）/ 已完成 / 全部
 * 2. 等级筛选：全部 / 闹钟级 / 横幅 / 普通 / 静默
 * 3. 列表：每项支持完成 / 删除
 * 4. 新建提醒（底部弹层）
 */
export default function RemindersPage() {
  const toast = useToast((s) => s.show)
  const [reminders, setReminders] = useState<Reminder[]>([])
  // 加载与错误状态兜底
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)
  const [showAdd, setShowAdd] = useState(false)
  const [tab, setTab] = useState<Tab>('pending')
  const [levelFilter, setLevelFilter] = useState<LevelFilter>('all')
  const [searchParams, setSearchParams] = useSearchParams()

  useEffect(() => {
    load()
    // 来自 HomePage 快捷入口 ?new=1 → 自动打开新增弹层
    if (searchParams.get('new') === '1') {
      setShowAdd(true)
      searchParams.delete('new')
      setSearchParams(searchParams, { replace: true })
    }
  }, [tab])

  const load = async () => {
    // 进入加载态，清除上一次错误
    setLoading(true)
    setError(false)
    try {
      // tab=pending → 只查未完成；done/all → 查全部后前端过滤
      const onlyPending = tab === 'pending'
      const list = await unwrap<Reminder[]>(api.get(`/reminder${onlyPending ? '?pending=1' : ''}`))
      setReminders(list)
    } catch (err) {
      // 标记错误状态并提示，渲染区将展示重试入口
      setError(true)
      toast((err as Error).message, 'error')
    } finally {
      setLoading(false)
    }
  }

  /** 前端二次过滤：按 tab + 等级 */
  const filtered = reminders.filter((r) => {
    if (tab === 'pending' && r.done) return false
    if (tab === 'done' && !r.done) return false
    if (levelFilter !== 'all' && r.level !== levelFilter) return false
    return true
  })

  const done = async (id: string) => {
    try {
      await unwrap(api.post(`/reminder/${id}/done`))
      toast('已完成', 'success')
      load()
    } catch (err) {
      toast((err as Error).message, 'error')
    }
  }

  const remove = async (id: string) => {
    try {
      await unwrap(api.delete(`/reminder/${id}`))
      load()
    } catch (err) {
      toast((err as Error).message, 'error')
    }
  }

  const tabs: { key: Tab; label: string }[] = [
    { key: 'pending', label: '待办' },
    { key: 'done', label: '已完成' },
    { key: 'all', label: '全部' },
  ]

  const levelFilters: { key: LevelFilter; label: string }[] = [
    { key: 'all', label: '全部' },
    ...REMINDER_LEVELS.map((l) => ({ key: l, label: reminderLevelMeta[l].label })),
  ]

  return (
    <div className="app-shell">
      <Header
        title="提醒"
        right={
          <button onClick={() => setShowAdd(true)} className="p-2 text-primary-600">
            <Plus size={20} />
          </button>
        }
      />
      {/* Tab 切换 */}
      <div className="sticky top-12 bg-white z-10 border-b border-gray-100">
        <div className="flex">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex-1 py-3 text-sm border-b-2 ${
                tab === t.key
                  ? 'border-primary-500 text-primary-600 font-medium'
                  : 'border-transparent text-gray-500'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
        {/* 等级筛选 */}
        <div className="flex gap-1.5 px-3 py-2 overflow-x-auto">
          {levelFilters.map((f) => (
            <button
              key={f.key}
              onClick={() => setLevelFilter(f.key)}
              className={`px-2.5 py-1 rounded-full text-xs whitespace-nowrap ${
                levelFilter === f.key
                  ? 'bg-primary-100 text-primary-600'
                  : 'bg-gray-50 text-gray-500'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <div className="px-3 py-3">
        {/* 列表：loading / error / empty / 正常列表 三态兜底 */}
        {loading ? (
          <LoadingState skeleton count={4} />
        ) : error ? (
          <ErrorState onRetry={load} />
        ) : filtered.length === 0 ? (
          <EmptyState
            icon="🔔"
            text={tab === 'pending' ? '暂无待办提醒' : tab === 'done' ? '暂无已完成提醒' : '暂无提醒'}
            hint={tab === 'pending' ? '点击右上角 + 创建提醒' : undefined}
          />
        ) : (
          <div className="space-y-2">
            {filtered.map((r) => {
              const meta = reminderLevelMeta[r.level] || reminderLevelMeta.normal
              return (
                <div key={r.id} className={`card group ${r.done ? 'opacity-60' : ''}`}>
                  <div className="flex items-start gap-3">
                    <span className={`mt-1.5 w-2 h-2 rounded-full ${meta.dot}`} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className={`text-sm text-gray-800 ${r.done ? 'line-through' : ''}`}>
                          {r.title}
                        </span>
                        <span className={`badge ${meta.color}`}>{meta.label}</span>
                      </div>
                      {r.content && <div className="text-xs text-gray-500 mt-0.5">{r.content}</div>}
                      <div className="text-xs text-gray-400 mt-1">
                        ⏰ {formatDateTime(r.remindAt)}
                        {r.repeat !== 'once' && <span className="ml-2">🔁 {r.repeat === 'daily' ? '每天' : r.repeat === 'weekly' ? '每周' : '每月'}</span>}
                      </div>
                    </div>
                    <div className="flex flex-col gap-1">
                      {!r.done && (
                        <button
                          onClick={() => done(r.id)}
                          className="p-1.5 text-gray-400 hover:text-green-500 rounded"
                        >
                          <Check size={16} />
                        </button>
                      )}
                      <button
                        onClick={() => remove(r.id)}
                        className="p-1.5 opacity-0 group-hover:opacity-100 text-gray-300 hover:text-red-500 rounded"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {showAdd && <AddReminderModal onClose={() => setShowAdd(false)} onAdded={load} />}
    </div>
  )
}

function AddReminderModal({ onClose, onAdded }: { onClose: () => void; onAdded: () => void }) {
  const toast = useToast((s) => s.show)
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [level, setLevel] = useState<typeof REMINDER_LEVELS[number]>('proper')
  const [remindAt, setRemindAt] = useState('')
  const [repeat, setRepeat] = useState<'once' | 'daily' | 'weekly' | 'monthly'>('once')
  const [loading, setLoading] = useState(false)

  const submit = async () => {
    if (!title || !remindAt) {
      toast('请填写标题和时间', 'error')
      return
    }
    setLoading(true)
    try {
      await unwrap(api.post('/reminder', { title, content, level, remindAt, repeat }))
      toast('提醒已创建', 'success')
      onAdded()
      onClose()
    } catch (err) {
      toast((err as Error).message, 'error')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/40" />
      <div
        className="relative bg-white w-full max-w-[480px] mx-auto rounded-t-2xl p-5 animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="text-lg font-semibold mb-4">新建提醒</h3>
        <div className="space-y-3">
          <input
            autoFocus
            className="input"
            placeholder="提醒标题"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <input
            className="input"
            placeholder="备注（可选）"
            value={content}
            onChange={(e) => setContent(e.target.value)}
          />
          <div>
            <label className="text-xs text-gray-500">提醒时间</label>
            <input
              type="datetime-local"
              className="input mt-1"
              value={remindAt}
              onChange={(e) => setRemindAt(e.target.value)}
            />
          </div>
          <div>
            <label className="text-xs text-gray-500">等级</label>
            <div className="grid grid-cols-4 gap-2 mt-1">
              {REMINDER_LEVELS.map((l) => (
                <button
                  key={l}
                  onClick={() => setLevel(l)}
                  className={`py-2 rounded-lg text-xs border ${
                    level === l ? 'border-primary-500 bg-primary-50 text-primary-600' : 'border-gray-200'
                  }`}
                >
                  {reminderLevelMeta[l].label}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-xs text-gray-500">重复</label>
            <div className="grid grid-cols-4 gap-2 mt-1">
              {(['once', 'daily', 'weekly', 'monthly'] as const).map((r) => (
                <button
                  key={r}
                  onClick={() => setRepeat(r)}
                  className={`py-2 rounded-lg text-xs border ${
                    repeat === r ? 'border-primary-500 bg-primary-50 text-primary-600' : 'border-gray-200'
                  }`}
                >
                  {r === 'once' ? '单次' : r === 'daily' ? '每天' : r === 'weekly' ? '每周' : '每月'}
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="flex gap-2 mt-5">
          <button onClick={onClose} className="btn-secondary flex-1">取消</button>
          <button onClick={submit} disabled={loading} className="btn-primary flex-1 disabled:opacity-50">
            {loading ? '创建中...' : '创建'}
          </button>
        </div>
      </div>
    </div>
  )
}
