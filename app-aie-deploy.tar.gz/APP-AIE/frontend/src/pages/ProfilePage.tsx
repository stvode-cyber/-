import { Link } from 'react-router-dom'
import { useAuthStore } from '../stores/auth'
import { useToast } from '../components/Toast'
import {
  Wallet, ListTodo, UtensilsCrossed, Coins, Bell, Shield, ChevronRight, LogOut,
  Settings, Award, Target, ClipboardList, Puzzle, Mic, Radio,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { toneMeta } from '../lib/utils'

/**
 * 个人中心页
 *
 * 由两大功能区组成：
 * 1. 常用功能：跳转到对应业务页（任务/饮食/财务/提醒/钱包/工作交接表）
 * 2. 账号与设置：安全中心跳 /wallet，设置跳 /settings（真实可用），
 *    实名认证 / 长远规划 为阶段二功能，明确标注"规划中"
 */
export default function ProfilePage() {
  const { user, logout } = useAuthStore()
  const toast = useToast((s) => s.show)

  /** 阶段二功能占位点击：明确提示规划中 */
  const onPlanned = (label: string) => {
    toast(`${label}为阶段二规划功能，敬请期待`, 'info')
  }

  const sections: { title: string; items: { to?: string; icon: LucideIcon; label: string; desc?: string; onClick?: () => void }[] }[] = [
    {
      title: '常用功能',
      items: [
        { to: '/tasks', icon: ListTodo, label: '任务日程' },
        { to: '/diet', icon: UtensilsCrossed, label: '饮食记录' },
        { to: '/finance', icon: Coins, label: '财务记账' },
        { to: '/reminders', icon: Bell, label: '提醒管理' },
        { to: '/wallet', icon: Wallet, label: '我的钱包' },
        { to: '/handover', icon: ClipboardList, label: '工作交接表' },
        { to: '/fragments', icon: Puzzle, label: '碎片收藏', desc: '对话中记录的文字 / 链接 / 想法' },
        { to: '/voice-memos', icon: Mic, label: '录音纪要', desc: '录音转写与待办提取' },
        { to: '/live-meeting', icon: Radio, label: '实时纪要', desc: '会议持续录音 · 自动切片' },
      ],
    },
    {
      title: '账号与设置',
      items: [
        // 安全中心跳转到 /wallet（已有支付密码/账户状态模块）
        { to: '/wallet', icon: Shield, label: '安全中心', desc: '支付密码 · 设备管理' },
        // 设置：跳转真实可用的设置页（个人资料 / 语气偏好 / 关于）
        { to: '/settings', icon: Settings, label: '设置', desc: '资料 · 语气偏好 · 关于' },
        // 实名认证：跳转认证中心（阶段二 SA-08/S-13 已实现）
        { to: '/verify', icon: Award, label: '实名认证', desc: 'Lv0-Lv5 五级认证体系' },
        // 阶段二规划功能：明确标注，不误导用户
        { icon: Target, label: '长远规划', desc: '阶段二规划中', onClick: () => onPlanned('长远规划') },
      ],
    },
  ]

  return (
    <div className="pb-4">
      {/* 头部 */}
      <div className="bg-gradient-to-br from-primary-600 to-primary-700 text-white px-4 pt-6 pb-8">
        <div className="flex items-center gap-3">
          <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur flex items-center justify-center text-2xl">
            {user?.avatar || '👤'}
          </div>
          <div className="flex-1">
            <div className="text-lg font-semibold">{user?.nickname || user?.username}</div>
            <div className="text-sm opacity-80">@{user?.username}</div>
            {user?.preferredTone && (
              <div className="mt-1 inline-flex items-center gap-1 text-xs bg-white/20 px-2 py-0.5 rounded-full">
                {toneMeta[user.preferredTone]?.emoji} {toneMeta[user.preferredTone]?.label}
              </div>
            )}
          </div>
        </div>

        {user?.primaryGoal && (
          <div className="mt-4 bg-white/15 backdrop-blur rounded-xl p-3">
            <div className="text-xs opacity-80">本周目标</div>
            <div className="text-sm mt-0.5">{user.primaryGoal}</div>
          </div>
        )}
      </div>

      {/* 功能区 */}
      <div className="px-3 -mt-4 space-y-3">
        {sections.map((sec) => (
          <div key={sec.title} className="card overflow-hidden p-0">
            <div className="px-4 pt-3 pb-1 text-xs text-gray-400">{sec.title}</div>
            <div>
              {sec.items.map((item, i) => {
                const inner = (
                  <>
                    <item.icon size={20} className="text-primary-500" />
                    <div className="flex-1">
                      <div className="text-sm text-gray-800">{item.label}</div>
                      {item.desc && <div className="text-xs text-gray-400">{item.desc}</div>}
                    </div>
                    <ChevronRight size={16} className="text-gray-300" />
                  </>
                )
                const cls = `flex items-center gap-3 px-4 py-3 hover:bg-gray-50 transition-colors ${
                  i < sec.items.length - 1 ? 'border-b border-gray-50' : ''
                }`
                // 有 to 的走路由跳转；占位项走 onClick
                return item.to ? (
                  <Link key={item.label} to={item.to} className={cls}>
                    {inner}
                  </Link>
                ) : (
                  <button
                    key={item.label}
                    onClick={item.onClick}
                    className={`${cls} w-full text-left`}
                  >
                    {inner}
                  </button>
                )
              })}
            </div>
          </div>
        ))}

        <button
          onClick={logout}
          className="card w-full flex items-center justify-center gap-2 py-3 text-red-500 hover:bg-red-50"
        >
          <LogOut size={18} />
          <span className="text-sm">退出登录</span>
        </button>

        <div className="text-center text-xs text-gray-400 py-2">
          AI小助 MVP v1.0.0
        </div>
      </div>
    </div>
  )
}
