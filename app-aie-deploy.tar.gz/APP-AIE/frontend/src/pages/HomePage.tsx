import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Bell, Search, Settings, Plus, ChevronRight, CheckSquare, Utensils, Wallet, Calendar, RefreshCw, ClipboardList, Moon, MapPin, Users, EyeOff } from 'lucide-react'
import { api, unwrap } from '../lib/api'
import { useAuthStore } from '../stores/auth'
import {
  formatTime, formatMoney, daysLeft, priorityMeta,
} from '../lib/utils'
import { useToast } from '../components/Toast'
import { LoadingState, ErrorState } from '../components/StateView'
import { useConfirm } from '../components/ConfirmDialog'
import {
  eventScopeMeta, EVENT_SCOPES, manualEventColorMeta, MANUAL_EVENT_COLORS,
} from '../lib/constants'

interface HomeTaskItem {
  id: string
  title: string
  priority: string
  status: string
  dueDate?: string | null
  important?: boolean
  category?: string
}

interface HomeReminderItem {
  id: string
  title: string
  remindAt: string
  level?: string
  done: boolean
}

interface HomeData {
  date: string
  greeting: string
  /** DG-12 场景化问候：按时段+当日数据生成的个性化问候 */
  sceneGreeting: {
    title: string
    subtitle: string
    tip: string
  }
  energy: number
  mood: string
  todayTip: string
  countdowns: { id: string; title: string; targetDate: string; days: number; icon: string }[]
  todayTasks: HomeTaskItem[]
  pendingTaskCount: number
  finance: { monthExpense: number; monthIncome: number; walletBalance: number }
  health: {
    todayMeals: number
    totalCalories: number
    suggestion: string
    // 昨晚睡眠数据（阶段二「睡眠分析」基础版）
    sleep: {
      durationMin: number
      quality?: number | null
      hint: string
    } | null
  }
  events: {
    id: string
    type: string
    title: string
    time: string
    priority?: string
    level?: string
    // 情境视角（EV-05）：work | life | finance
    scope: 'work' | 'life' | 'finance'
    // EV-06 事件手动管理：手动事件携带的扩展字段
    manual?: boolean
    important?: boolean
    location?: string | null
    attendees?: string[]
    color?: string
  }[]
  // 事件冲突（EV-02）：相邻事件间隔 < 15min 的冲突对
  conflicts: {
    a: { id: string; type: string; title: string; time: string }
    b: { id: string; type: string; title: string; time: string }
    gapMin: number
    suggestion: string
  }[]
  // DG-05 每日一问：基于当日数据的启发式问题
  dailyQuestion: {
    question: string
    hint: string
    action: string
  }
  /** DG-14 成就激励：今日进度 + 连续记录 + 徽章 */
  achievements: {
    todayProgress: { done: number; total: number; rate: number }
    streaks: { label: string; days: number; emoji: string }[]
    badges: { key: string; label: string; emoji: string; unlocked: boolean; hint: string }[]
    encouragement: string
  }
  reminders: HomeReminderItem[]
  handover: {
    draft: { id: string; title: string; updatedAt: string } | null
    pendingItemCount: number
  }
}

/**
 * 主页 · 今日全景
 *
 * 页面结构（自上而下）：
 * 1. 顶部状态栏（日常模式 / 通知 / 设置）
 * 2. 用户问候卡片
 * 3. 跨模块快捷入口（6 个圆形图标，交接工作点）
 * 4. 今日全景卡（精力 + 心情 + AI 提示）
 * 5. 倒计时（最近 3 个未完成任务）
 * 6. 今日待办（最多 5 条 + "添加任务"入口）
 * 7. 财务速览（本月支出/收入/钱包余额）
 * 8. 健康摘要（餐数/热量/建议）
 * 9. 事件总汇（今日待办 + 提醒按时间排序）
 *
 * 数据来源：GET /home/today
 */
export default function HomePage() {
  const { user } = useAuthStore()
  const navigate = useNavigate()
  const toast = useToast((s) => s.show)
  const confirm = useConfirm()
  const [data, setData] = useState<HomeData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)
  // EV-05 情境视角切换：all | work | life | finance
  const [scope, setScope] = useState<'all' | 'work' | 'life' | 'finance'>('all')
  // EV-06 添加事件弹层
  const [showAddEvent, setShowAddEvent] = useState(false)
  // EV-06 隐藏事件中的操作中事件 id（防止重复点击）
  const [hidingId, setHidingId] = useState<string | null>(null)
  // EV-03 事件详情弹层（null=关闭；非 null=当前查看的事件）
  const [detailEvent, setDetailEvent] = useState<HomeData['events'][number] | null>(null)
  // DG-05 每日一问
  const [dailyQuestion, setDailyQuestion] = useState<{ question: string; topic: string; hint: string | null; date: string } | null>(null)
  const [dailyQuestionLoading, setDailyQuestionLoading] = useState(false)
  // DG-13 状态感知互动（疲劳/压力关怀）
  const [wellness, setWellness] = useState<{
    needCare: boolean
    level: 'gentle' | 'suggest' | 'urgent'
    title: string
    message: string
    suggestions: Array<{ label: string; desc: string; to?: string; emoji: string }>
    signals: string[]
  } | null>(null)
  // DG-13 用户已关闭关怀卡片（本次会话内不再显示）
  const [wellnessDismissed, setWellnessDismissed] = useState(false)
  // DG-15 迷茫期引导
  const [confusion, setConfusion] = useState<{
    needGuide: boolean
    level: 'light' | 'moderate' | 'deep'
    title: string
    message: string
    guideActions: Array<{ label: string; desc: string; to?: string; emoji: string }>
    signals: string[]
  } | null>(null)
  // DG-15 用户已关闭引导卡片（本次会话内不再显示）
  const [confusionDismissed, setConfusionDismissed] = useState(false)

  const load = async () => {
    setLoading(true)
    setError(false)
    try {
      // DG-05/DG-13/DG-15 与 home/today 并行加载（不阻塞主数据）
      const [res] = await Promise.all([
        unwrap<HomeData>(api.get('/home/today')),
        // 每日一问失败不阻塞主页加载
        (async () => {
          try {
            const dq = await unwrap<{ question: string; topic: string; hint: string | null; date: string }>(
              api.get('/home/daily-question')
            )
            setDailyQuestion(dq)
          } catch {
            // 静默失败：每日一问不是核心功能
          }
        })(),
        // DG-13 状态感知：失败不阻塞主页
        (async () => {
          try {
            const w = await unwrap<{
              needCare: boolean
              level: 'gentle' | 'suggest' | 'urgent'
              title: string
              message: string
              suggestions: Array<{ label: string; desc: string; to?: string; emoji: string }>
              signals: string[]
            }>(api.get('/home/wellness-check'))
            setWellness(w)
            setWellnessDismissed(false)
          } catch {
            // 静默失败
          }
        })(),
        // DG-15 迷茫期引导：失败不阻塞主页
        (async () => {
          try {
            const c = await unwrap<{
              needGuide: boolean
              level: 'light' | 'moderate' | 'deep'
              title: string
              message: string
              guideActions: Array<{ label: string; desc: string; to?: string; emoji: string }>
              signals: string[]
            }>(api.get('/home/confusion-check'))
            setConfusion(c)
            setConfusionDismissed(false)
          } catch {
            // 静默失败
          }
        })(),
      ])
      setData(res)
    } catch (err) {
      setError(true)
      toast((err as Error).message, 'error')
    } finally {
      setLoading(false)
    }
  }

  /**
   * DG-05 单独刷新每日一问（用户点击"换一题"时）
   * 注意：因问题由日期决定，"换一题"实际是从问题池中随机抽一道同主题的备选问题
   */
  const refreshDailyQuestion = async () => {
    setDailyQuestionLoading(true)
    try {
      const res = await unwrap<{ question: string; topic: string; hint: string | null; date: string }>(
        api.get('/home/daily-question')
      )
      setDailyQuestion(res)
    } catch (err) {
      toast((err as Error).message, 'error')
    } finally {
      setDailyQuestionLoading(false)
    }
  }

  /**
   * EV-06 隐藏事件
   * - 手动事件（type=manual）：PATCH /manual-events/:id 设置 hidden=true
   * - 自动事件（type=task/reminder 等）：POST /manual-events/hidden-auto 记录到 HiddenEvent
   */
  const hideEvent = async (ev: HomeData['events'][number]) => {
    const ok = await confirm({
      title: '隐藏事件',
      message: `将从事件总览中隐藏「${ev.title}」，可在事件管理页恢复。`,
      confirmText: '隐藏',
      danger: true,
    })
    if (!ok) return
    setHidingId(`${ev.type}-${ev.id}`)
    try {
      if (ev.type === 'manual') {
        await unwrap(api.patch(`/manual-events/${ev.id}`, { hidden: true }))
      } else {
        await unwrap(api.post('/manual-events/hidden-auto', {
          sourceType: ev.type,
          sourceId: ev.id,
        }))
      }
      toast('已隐藏', 'success')
      await load()
    } catch (err) {
      toast((err as Error).message, 'error')
    } finally {
      setHidingId(null)
    }
  }

  /**
   * EV-03 打开事件详情弹层
   * 由事件项点击触发，查询 GET /manual-events/:id/detail?type=...
   */
  const openDetail = (ev: HomeData['events'][number]) => {
    setDetailEvent(ev)
  }

  useEffect(() => {
    load()
  }, [])

  const today = new Date()
  const weekDay = ['日', '一', '二', '三', '四', '五', '六'][today.getDay()]

  // 跨模块快捷入口（交接工作点）
  // 新增类入口携带 ?new=1，对应页面 mount 时自动打开新增弹层
  const quickActions = [
    { icon: CheckSquare, label: '添加任务', to: '/tasks?new=1', color: 'text-purple-600 bg-purple-50' },
    { icon: Utensils, label: '记录饮食', to: '/diet?new=1', color: 'text-orange-600 bg-orange-50' },
    { icon: Moon, label: '记录睡眠', to: '/sleep?new=1', color: 'text-indigo-600 bg-indigo-50' },
    { icon: Plus, label: '记一笔账', to: '/finance?new=1', color: 'text-green-600 bg-green-50' },
    { icon: Wallet, label: '充值钱包', to: '/wallet/recharge', color: 'text-yellow-600 bg-yellow-50' },
    { icon: Calendar, label: '新建提醒', to: '/reminders?new=1', color: 'text-blue-600 bg-blue-50' },
    { icon: ClipboardList, label: '工作交接', to: '/handover?new=1', color: 'text-teal-600 bg-teal-50' },
  ]

  return (
    <div className="pb-4">
      {/* 状态栏 */}
      <div className="sticky top-0 z-30 bg-gradient-to-r from-primary-600 to-primary-500 text-white">
        <div className="flex items-center justify-between h-11 px-4 text-sm">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-300 animate-pulse" />
            <span className="opacity-90">日常模式</span>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => navigate('/search')} aria-label="搜索">
              <Search size={18} />
            </button>
            <button
              onClick={load}
              className="relative"
              aria-label="刷新"
              disabled={loading}
            >
              <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
            </button>
            <Link to="/reminders" className="relative">
              <Bell size={18} />
              {data && data.events.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center">
                  {data.events.length}
                </span>
              )}
            </Link>
            <Link to="/profile"><Settings size={18} /></Link>
          </div>
        </div>
        <div className="px-4 pb-3">
          <div className="flex items-start gap-2">
            <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur flex items-center justify-center text-lg flex-shrink-0">
              {user?.avatar || '👤'}
            </div>
            <div className="flex-1 min-w-0">
              {/* DG-12 场景化问候：title 主问候 + subtitle 次级信息 */}
              <div className="font-medium leading-snug">
                {data?.sceneGreeting?.title || data?.greeting || '你好'}，{user?.nickname || user?.username}
              </div>
              {data?.sceneGreeting?.subtitle && (
                <div className="text-xs opacity-80 mt-0.5">{data.sceneGreeting.subtitle}</div>
              )}
              <div className="text-xs opacity-60 mt-1">今天周{weekDay} · {today.getMonth() + 1}月{today.getDate()}日</div>
            </div>
          </div>
          {/* DG-12 场景化问候：tip 场景化建议 */}
          {data?.sceneGreeting?.tip && (
            <div className="mt-2 bg-white/15 backdrop-blur rounded-lg px-3 py-1.5 text-xs opacity-90">
              💡 {data.sceneGreeting.tip}
            </div>
          )}
        </div>
      </div>

      {/* DG-13 状态感知互动：疲劳/压力关怀卡片 */}
      {wellness && wellness.needCare && !wellnessDismissed && (
        <div className={`mx-3 my-3 p-4 rounded-2xl border ${
          wellness.level === 'urgent'
            ? 'bg-gradient-to-br from-rose-50 to-orange-50 border-rose-200'
            : wellness.level === 'suggest'
              ? 'bg-gradient-to-br from-amber-50 to-yellow-50 border-amber-200'
              : 'bg-gradient-to-br from-sky-50 to-indigo-50 border-sky-200'
        }`}>
          <div className="flex items-start gap-3">
            <span className="text-2xl flex-shrink-0">
              {wellness.level === 'urgent' ? '🤗' : wellness.level === 'suggest' ? '🌿' : '☁️'}
            </span>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <span className={`text-[10px] uppercase tracking-wider font-medium ${
                  wellness.level === 'urgent' ? 'text-rose-500'
                    : wellness.level === 'suggest' ? 'text-amber-600'
                      : 'text-sky-500'
                }`}>
                  {wellness.level === 'urgent' ? '需要关怀'
                    : wellness.level === 'suggest' ? '留意一下'
                      : '小提示'}
                </span>
                <button
                  onClick={() => setWellnessDismissed(true)}
                  className="text-gray-400 hover:text-gray-600 text-xs"
                  title="本次会话不再显示"
                >
                  ✕
                </button>
              </div>
              <div className="text-sm font-semibold text-gray-800">
                {wellness.title}
              </div>
              <div className="text-xs text-gray-600 mt-1 leading-relaxed">
                {wellness.message}
              </div>
              {wellness.suggestions.length > 0 && (
                <div className="mt-3 space-y-2">
                  {wellness.suggestions.map((s, i) => (
                    <button
                      key={`${s.label}-${i}`}
                      onClick={() => {
                        if (s.to) {
                          navigate(s.to)
                        } else {
                          // 无跳转的方案：复制内容到剪贴板，引导用户行动
                          navigator.clipboard?.writeText(s.desc).then(
                            () => toast(`已复制：${s.label}`, 'success'),
                            () => toast('复制失败', 'error'),
                          )
                        }
                      }}
                      className="w-full flex items-start gap-2 p-2 rounded-lg bg-white/60 hover:bg-white text-left transition-colors"
                    >
                      <span className="text-lg flex-shrink-0">{s.emoji}</span>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-medium text-gray-700">{s.label}</div>
                        <div className="text-[11px] text-gray-500 mt-0.5">{s.desc}</div>
                      </div>
                      {s.to && (
                        <ChevronRight size={14} className="text-gray-400 flex-shrink-0 mt-1" />
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* DG-15 迷茫期引导：低活动量/无目标引导卡片 */}
      {confusion && confusion.needGuide && !confusionDismissed && (
        <div className={`mx-3 my-3 p-4 rounded-2xl border ${
          confusion.level === 'deep'
            ? 'bg-gradient-to-br from-violet-50 to-indigo-50 border-violet-200'
            : confusion.level === 'moderate'
              ? 'bg-gradient-to-br from-teal-50 to-cyan-50 border-teal-200'
              : 'bg-gradient-to-br from-emerald-50 to-green-50 border-emerald-200'
        }`}>
          <div className="flex items-start gap-3">
            <span className="text-2xl flex-shrink-0">
              {confusion.level === 'deep' ? '🧭' : confusion.level === 'moderate' ? '🌿' : '🌱'}
            </span>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <span className={`text-[10px] uppercase tracking-wider font-medium ${
                  confusion.level === 'deep' ? 'text-violet-500'
                    : confusion.level === 'moderate' ? 'text-teal-600'
                      : 'text-emerald-600'
                }`}>
                  {confusion.level === 'deep' ? '需要方向'
                    : confusion.level === 'moderate' ? '找个起点'
                      : '小提示'}
                </span>
                <button
                  onClick={() => setConfusionDismissed(true)}
                  className="text-gray-400 hover:text-gray-600 text-xs"
                  title="本次会话不再显示"
                >
                  ✕
                </button>
              </div>
              <div className="text-sm font-semibold text-gray-800">
                {confusion.title}
              </div>
              <div className="text-xs text-gray-600 mt-1 leading-relaxed">
                {confusion.message}
              </div>
              {confusion.guideActions.length > 0 && (
                <div className="mt-3 space-y-2">
                  {confusion.guideActions.map((a, i) => (
                    <button
                      key={`${a.label}-${i}`}
                      onClick={() => a.to && navigate(a.to)}
                      className="w-full flex items-start gap-2 p-2 rounded-lg bg-white/60 hover:bg-white text-left transition-colors"
                    >
                      <span className="text-lg flex-shrink-0">{a.emoji}</span>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-medium text-gray-700">{a.label}</div>
                        <div className="text-[11px] text-gray-500 mt-0.5">{a.desc}</div>
                      </div>
                      {a.to && (
                        <ChevronRight size={14} className="text-gray-400 flex-shrink-0 mt-1" />
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* DG-05 每日一问：基于当日数据的启发式问题 */}
      {data && data.dailyQuestion && (
        <div className="px-3 pt-3">
          <button
            onClick={() => {
              // 将问题文本作为消息发送到对话页
              navigate('/chat', { state: { prefillMessage: data.dailyQuestion.action } })
            }}
            className="card w-full text-left bg-gradient-to-br from-amber-50 to-white border-amber-100"
          >
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center text-lg flex-shrink-0">
                💭
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs text-amber-600 font-medium mb-1">每日一问</div>
                <div className="text-sm text-gray-800 leading-relaxed">
                  {data.dailyQuestion.question}
                </div>
                <div className="text-xs text-gray-400 mt-1.5 flex items-center gap-1">
                  <span>💡 {data.dailyQuestion.hint}</span>
                </div>
                <div className="text-xs text-primary-600 mt-2 flex items-center gap-1">
                  点击和 AI 聊聊 <ChevronRight size={12} />
                </div>
              </div>
            </div>
          </button>
        </div>
      )}

      {/* DG-14 成就激励：今日进度 + 连续记录 + 徽章 */}
      {data && data.achievements && (
        <div className="px-3 pt-3">
          <div className="card bg-gradient-to-br from-emerald-50 to-white border-emerald-100">
            {/* 头部：鼓励文案 + 今日进度 */}
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-lg flex-shrink-0">
                🏆
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs text-emerald-600 font-medium mb-1">今日成就</div>
                <div className="text-sm text-gray-800 leading-relaxed">
                  {data.achievements.encouragement}
                </div>
                {/* 今日进度条 */}
                {data.achievements.todayProgress.total > 0 && (
                  <div className="mt-2">
                    <div className="flex items-center justify-between text-[10px] text-gray-500 mb-0.5">
                      <span>今日完成 {data.achievements.todayProgress.done} / {data.achievements.todayProgress.total}</span>
                      <span>{data.achievements.todayProgress.rate}%</span>
                    </div>
                    <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-emerald-400 to-emerald-500 rounded-full transition-all"
                        style={{ width: `${data.achievements.todayProgress.rate}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* 连续记录 */}
            {data.achievements.streaks.length > 0 && (
              <div className="mt-3 pt-3 border-t border-emerald-50 flex flex-wrap gap-2">
                {data.achievements.streaks.map((s) => (
                  <div
                    key={s.label}
                    className="text-[10px] px-2 py-1 rounded-full bg-white text-gray-600 border border-emerald-100 flex items-center gap-1"
                  >
                    <span>{s.emoji}</span>
                    <span>{s.label}</span>
                    <span className="text-emerald-600 font-medium">{s.days} 天</span>
                  </div>
                ))}
              </div>
            )}

            {/* 成就徽章 */}
            <div className="mt-3 pt-3 border-t border-emerald-50">
              <div className="text-[10px] text-gray-400 mb-1.5">成就徽章</div>
              <div className="flex flex-wrap gap-2">
                {data.achievements.badges.map((b) => (
                  <div
                    key={b.key}
                    title={b.hint}
                    className={`text-[10px] px-2 py-1 rounded-full border flex items-center gap-1 ${
                      b.unlocked
                        ? 'bg-emerald-50 text-emerald-600 border-emerald-200'
                        : 'bg-gray-50 text-gray-400 border-gray-100'
                    }`}
                  >
                    <span className={b.unlocked ? '' : 'opacity-40 grayscale'}>{b.emoji}</span>
                    <span>{b.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* DG-05 每日一问 */}
      {dailyQuestion && (
        <div className="mx-3 my-3 p-4 rounded-2xl bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 border border-indigo-100">
          <div className="flex items-start gap-3">
            <span className="text-2xl flex-shrink-0">🤔</span>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] uppercase tracking-wider text-indigo-500 font-medium">
                  每日一问 · {dailyQuestion.topic}
                </span>
                <button
                  onClick={refreshDailyQuestion}
                  disabled={dailyQuestionLoading}
                  className="text-[11px] text-indigo-400 hover:text-indigo-600 disabled:opacity-40"
                  title="换一题"
                >
                  {dailyQuestionLoading ? '...' : '↻ 换一题'}
                </button>
              </div>
              <div className="text-sm text-gray-800 font-medium leading-relaxed">
                {dailyQuestion.question}
              </div>
              {dailyQuestion.hint && (
                <div className="text-xs text-gray-500 mt-2 italic">
                  💡 {dailyQuestion.hint}
                </div>
              )}
              <div className="flex gap-2 mt-3">
                <button
                  onClick={() => {
                    // 跳转到对话页，并将问题作为初始输入
                    navigate('/chat', { state: { initialInput: dailyQuestion.question } })
                  }}
                  className="text-[11px] px-3 py-1 rounded-full bg-indigo-500 text-white hover:bg-indigo-600"
                >
                  去对话中思考
                </button>
                <button
                  onClick={() => {
                    // 复制问题到剪贴板
                    navigator.clipboard?.writeText(dailyQuestion.question).then(
                      () => toast('已复制到剪贴板', 'success'),
                      () => toast('复制失败', 'error'),
                    )
                  }}
                  className="text-[11px] px-3 py-1 rounded-full bg-white text-indigo-600 border border-indigo-200 hover:bg-indigo-50"
                >
                  复制
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 跨模块快捷入口（交接工作点） */}
      <div className="px-3 py-3 bg-white border-b border-gray-50">
        <div className="grid grid-cols-4 gap-1">
          {quickActions.map((a) => {
            const Icon = a.icon
            return (
              <Link
                key={a.label}
                to={a.to}
                className="flex flex-col items-center gap-1 py-2 group"
              >
                <div className={`w-9 h-9 rounded-full flex items-center justify-center ${a.color} group-hover:scale-105 transition-transform`}>
                  <Icon size={16} />
                </div>
                <span className="text-[10px] text-gray-500 group-hover:text-gray-700">{a.label}</span>
              </Link>
            )
          })}
        </div>
      </div>

      {loading ? (
        <LoadingState />
      ) : error ? (
        <ErrorState text="数据加载失败" onRetry={load} />
      ) : data ? (
        <div className="px-3 py-3 space-y-3">
          {/* 今日全景 */}
          <div className="card bg-gradient-to-br from-primary-50 to-white">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-lg">💡</span>
              <span className="font-medium text-gray-800">今日全景</span>
            </div>
            <div className="flex items-center gap-4 mb-2 text-sm">
              <span className="text-gray-600">精力 <b className="text-primary-600">{data.energy}%</b></span>
              <span className="text-gray-600">心情 <b>{data.mood}</b></span>
            </div>
            <p className="text-sm text-gray-600 leading-relaxed">"{data.todayTip}"</p>
          </div>

          {/* 工作交接提示（有草稿或待跟进事项时显示） */}
          {(data.handover.draft || data.handover.pendingItemCount > 0) && (
            <Link
              to="/handover"
              className="card block bg-gradient-to-br from-teal-50 to-white border-teal-100"
            >
              <div className="flex items-center gap-2 mb-2">
                <span className="text-lg">📋</span>
                <span className="font-medium text-gray-800">工作交接</span>
                {data.handover.draft && (
                  <span className="badge bg-gray-100 text-gray-600">草稿待提交</span>
                )}
              </div>
              {data.handover.draft ? (
                <div className="text-sm text-gray-700 truncate">
                  {data.handover.draft.title}
                </div>
              ) : (
                <div className="text-sm text-gray-600">
                  共 {data.handover.pendingItemCount} 项待跟进事项
                </div>
              )}
              {data.handover.pendingItemCount > 0 && (
                <div className="text-xs text-orange-500 mt-1">
                  ⏳ 待跟进 {data.handover.pendingItemCount} 项
                </div>
              )}
            </Link>
          )}

          {/* 倒计时 */}
          {data.countdowns.length > 0 && (
            <div className="card">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-lg">⏰</span>
                <span className="font-medium text-gray-800">倒计时</span>
              </div>
              <div className="space-y-2">
                {data.countdowns.map((c) => (
                  <Link
                    key={c.id}
                    to={`/tasks`}
                    className="flex items-center justify-between py-1.5 group"
                  >
                    <div className="flex items-center gap-2">
                      <span>{c.icon}</span>
                      <span className="text-sm text-gray-700 group-hover:text-primary-600">{c.title}</span>
                    </div>
                    <span className={`text-sm font-medium ${c.days <= 3 ? 'text-red-500' : 'text-gray-600'}`}>
                      {c.days}天
                    </span>
                  </Link>
                ))}
              </div>
            </div>
          )}

          {/* 今日待办 */}
          <div className="card">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="text-lg">📋</span>
                <span className="font-medium text-gray-800">今日待办</span>
                <span className="badge bg-gray-100 text-gray-600">{data.pendingTaskCount}</span>
              </div>
              <Link to="/tasks" className="text-xs text-primary-600 flex items-center">
                全部 <ChevronRight size={14} />
              </Link>
            </div>
            {data.todayTasks.length === 0 ? (
              <div className="py-4 text-center text-sm text-gray-400">
                暂无待办，享受悠闲时光~
              </div>
            ) : (
              <div className="space-y-2">
                {data.todayTasks.map((t) => {
                  const meta = priorityMeta[t.priority] || priorityMeta.medium
                  return (
                    <Link
                      key={t.id}
                      to="/tasks"
                      className="flex items-center gap-2 py-1.5 group"
                    >
                      <span className={`w-2 h-2 rounded-full ${meta.bg}`} />
                      <span className="text-sm text-gray-700 flex-1 truncate group-hover:text-primary-600">
                        {t.important && '🔴 '}{t.title}
                      </span>
                      {t.dueDate && (
                        <span className="text-xs text-gray-400">{formatTime(t.dueDate)}</span>
                      )}
                    </Link>
                  )
                })}
              </div>
            )}
            <Link
              to="/tasks"
              className="mt-3 flex items-center justify-center gap-1 py-2 border border-dashed border-gray-200 rounded-lg text-sm text-gray-400 hover:border-primary-400 hover:text-primary-500"
            >
              <Plus size={14} /> 添加任务
            </Link>
          </div>

          {/* 财务速览 */}
          <div className="card">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="text-lg">💰</span>
                <span className="font-medium text-gray-800">财务速览</span>
              </div>
              <Link to="/finance" className="text-xs text-primary-600 flex items-center">
                详情 <ChevronRight size={14} />
              </Link>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="py-2">
                <div className="text-xs text-gray-400">本月支出</div>
                <div className="text-sm font-medium text-red-500">{formatMoney(data.finance.monthExpense)}</div>
              </div>
              <div className="py-2 border-x border-gray-100">
                <div className="text-xs text-gray-400">本月收入</div>
                <div className="text-sm font-medium text-green-500">{formatMoney(data.finance.monthIncome)}</div>
              </div>
              <Link to="/wallet" className="py-2">
                <div className="text-xs text-gray-400">钱包余额</div>
                <div className="text-sm font-medium text-primary-600">{formatMoney(data.finance.walletBalance)}</div>
              </Link>
            </div>
          </div>

          {/* 健康摘要 */}
          <div className="card">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="text-lg">🏃</span>
                <span className="font-medium text-gray-800">健康摘要</span>
              </div>
              <Link to="/diet" className="text-xs text-primary-600 flex items-center">
                记录 <ChevronRight size={14} />
              </Link>
            </div>
            <div className="flex items-center gap-4 text-sm text-gray-600">
              <span>🍱 今日{data.health.todayMeals}餐</span>
              <span>·</span>
              <span>🔥 {data.health.totalCalories}kcal</span>
            </div>
            {/* 昨晚睡眠（阶段二「睡眠分析」基础版） */}
            {data.health.sleep && (
              <Link
                to="/sleep"
                className="mt-3 pt-3 border-t border-gray-100 flex items-center justify-between hover:bg-gray-50 -mx-2 px-2 py-1 rounded"
              >
                <div className="flex items-center gap-2 text-sm">
                  <span>😴</span>
                  <span className="text-gray-600">
                    昨晚睡了 <b className="text-indigo-600">
                      {Math.floor(data.health.sleep.durationMin / 60)}h {data.health.sleep.durationMin % 60}min
                    </b>
                  </span>
                  {data.health.sleep.quality && (
                    <span className="badge bg-indigo-50 text-indigo-600 text-[10px]">Q{data.health.sleep.quality}</span>
                  )}
                </div>
                <ChevronRight size={14} className="text-gray-300" />
              </Link>
            )}
            <p className="mt-2 text-xs text-gray-500">
              {data.health.sleep?.hint || data.health.suggestion}
            </p>
          </div>

          {/* 事件总汇 */}
          <div className="card">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="text-lg">📅</span>
                <span className="font-medium text-gray-800">事件总汇</span>
                {data.conflicts.length > 0 && (
                  <span className="badge bg-orange-100 text-orange-700 text-[10px]">
                    {data.conflicts.length} 冲突
                  </span>
                )}
                {data.events.filter((e) => e.manual).length > 0 && (
                  <span className="badge bg-purple-100 text-purple-700 text-[10px]">
                    {data.events.filter((e) => e.manual).length} 手动
                  </span>
                )}
              </div>
              {/* EV-06 添加事件按钮 */}
              <button
                onClick={() => setShowAddEvent(true)}
                className="flex items-center gap-1 text-xs text-primary-600 hover:text-primary-700"
              >
                <Plus size={14} />
                <span>添加事件</span>
              </button>
            </div>
            {/* EV-05 情境视角切换：all | work | life | finance */}
            <div className="mb-3 flex gap-1 bg-gray-50 p-1 rounded-lg">
              {([
                { key: 'all', label: '全部' },
                ...EVENT_SCOPES.map((k) => ({ key: k, label: `${eventScopeMeta[k].emoji} ${eventScopeMeta[k].label}` })),
              ] as const).map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setScope(tab.key)}
                  className={`flex-1 py-1 text-xs rounded-md transition-colors ${
                    scope === tab.key
                      ? 'bg-white text-primary-600 shadow-sm'
                      : 'text-gray-500'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
            {/* 事件冲突提示（EV-02） */}
            {data.conflicts.length > 0 && (
              <div className="mb-3 space-y-2">
                {data.conflicts.map((c, i) => (
                  <div
                    key={`${c.a.id}-${c.b.id}-${i}`}
                    className="bg-orange-50 border border-orange-100 rounded-lg p-2 text-xs"
                  >
                    <div className="flex items-center gap-1 text-orange-600 font-medium mb-1">
                      <span>⚠️</span>
                      <span>时间冲突 · 间隔 {c.gapMin} 分钟</span>
                    </div>
                    <div className="text-gray-600">
                      <span className="text-gray-400">{formatTime(c.a.time)}</span>
                      {' '}
                      {c.a.title}
                      <span className="text-gray-300 mx-1">→</span>
                      <span className="text-gray-400">{formatTime(c.b.time)}</span>
                      {' '}
                      {c.b.title}
                    </div>
                    <div className="text-orange-500 mt-1">{c.suggestion}</div>
                  </div>
                ))}
              </div>
            )}
            <div className="space-y-3">
              {data.events
                .filter((ev) => scope === 'all' || ev.scope === scope)
                .map((ev) => {
                  const isUrgent = ev.priority === 'urgent' || ev.level === 'urgent'
                  // EV-06 手动事件使用 color 字段；自动事件按紧急度
                  const scopeMeta = eventScopeMeta[ev.scope] || eventScopeMeta.life
                  const dotColor = ev.manual
                    ? (manualEventColorMeta[ev.color || 'blue']?.dot || 'bg-blue-400')
                    : isUrgent
                      ? 'bg-red-500'
                      : ev.priority === 'high'
                        ? 'bg-orange-400'
                        : 'bg-blue-400'
                  const isHiding = hidingId === `${ev.type}-${ev.id}`
                  return (
                    <div key={`${ev.type}-${ev.id}`} className="flex gap-3 group">
                      <div className="flex flex-col items-center">
                        <span className={`w-2 h-2 rounded-full ${dotColor}`} />
                        <span className="w-px flex-1 bg-gray-100 mt-1" />
                      </div>
                      <div className="pb-2 flex-1">
                        <button
                          onClick={() => openDetail(ev)}
                          className="block w-full text-left"
                        >
                          <div className="text-xs text-gray-400 flex items-center gap-1">
                            {formatTime(ev.time)}
                            <span className="text-[10px]">{scopeMeta.emoji}</span>
                            {ev.manual && (
                              <span className="text-[10px] text-purple-500">手动</span>
                            )}
                          </div>
                          <div className="text-sm text-gray-700 mt-0.5 flex items-start gap-1">
                            <span className="flex-1">{ev.title}</span>
                          </div>
                        </button>
                        <div className="flex items-start gap-1 mt-0.5">
                          {/* EV-06 隐藏事件按钮 */}
                          <button
                            onClick={() => hideEvent(ev)}
                            disabled={isHiding}
                            title="隐藏此事件"
                            className="opacity-0 group-hover:opacity-100 transition-opacity text-gray-400 hover:text-gray-600 disabled:opacity-30"
                          >
                            <EyeOff size={14} />
                          </button>
                        </div>
                        {/* EV-06 手动事件扩展信息：地点 / 参与人物 */}
                        {ev.manual && (ev.location || (ev.attendees && ev.attendees.length > 0)) && (
                          <div className="flex flex-wrap gap-2 mt-1 text-[11px] text-gray-500">
                            {ev.location && (
                              <span className="flex items-center gap-0.5">
                                <MapPin size={10} />
                                {ev.location}
                              </span>
                            )}
                            {ev.attendees && ev.attendees.length > 0 && (
                              <span className="flex items-center gap-0.5">
                                <Users size={10} />
                                {ev.attendees.join('、')}
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  )
                })}
              {/* 当前视角下无事件时提示 */}
              {data.events.filter((ev) => scope === 'all' || ev.scope === scope).length === 0 && (
                <div className="text-center text-xs text-gray-400 py-4">
                  {scope === 'all' ? '今日暂无事件，点击右上角添加' : `当前视角暂无${
                    scope === 'work' ? '工作' : scope === 'life' ? '生活' : '财务'
                  }事件`}
                </div>
              )}
            </div>
          </div>
        </div>
      ) : null}

      {/* EV-06 添加事件弹层 */}
      {showAddEvent && (
        <AddEventModal
          onClose={() => setShowAddEvent(false)}
          onAdded={() => {
            setShowAddEvent(false)
            load()
          }}
        />
      )}

      {/* EV-03 事件详情弹层 */}
      {detailEvent && (
        <EventDetailModal
          event={detailEvent}
          onClose={() => setDetailEvent(null)}
        />
      )}
    </div>
  )
}

/**
 * EV-06 添加事件弹层
 *
 * 创建手动事件（ManualEvent），用户可自定义标题、时间、视角、地点、参与人、颜色。
 * 创建后通过 home/today 接口聚合到事件总览中显示。
 */
function AddEventModal({ onClose, onAdded }: { onClose: () => void; onAdded: () => void }) {
  const toast = useToast((s) => s.show)
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [startTime, setStartTime] = useState('')
  const [endTime, setEndTime] = useState('')
  const [scope, setScope] = useState<typeof EVENT_SCOPES[number]>('life')
  const [location, setLocation] = useState('')
  const [attendeesText, setAttendeesText] = useState('')
  const [color, setColor] = useState<typeof MANUAL_EVENT_COLORS[number]>('blue')
  const [loading, setLoading] = useState(false)

  const submit = async () => {
    if (!title.trim()) {
      toast('请填写事件标题', 'error')
      return
    }
    if (!startTime) {
      toast('请选择开始时间', 'error')
      return
    }
    // 将本地时间（datetime-local 输入）解析为 ISO 字符串
    const startISO = new Date(startTime).toISOString()
    const endISO = endTime ? new Date(endTime).toISOString() : undefined
    if (endISO && new Date(endISO).getTime() < new Date(startISO).getTime()) {
      toast('结束时间不能早于开始时间', 'error')
      return
    }

    const attendees = attendeesText
      .split(/[,，;；\s]+/)
      .map((s) => s.trim())
      .filter(Boolean)

    setLoading(true)
    try {
      await unwrap(api.post('/manual-events', {
        title: title.trim(),
        description: description.trim() || undefined,
        startTime: startISO,
        endTime: endISO,
        scope,
        location: location.trim() || undefined,
        attendees: attendees.length > 0 ? attendees : undefined,
        color,
      }))
      toast('事件已添加', 'success')
      onAdded()
    } catch (err) {
      toast((err as Error).message, 'error')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/40" />
      <div
        className="relative bg-white w-full max-w-[480px] mx-auto rounded-t-2xl p-5 animate-slide-up max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="text-lg font-semibold mb-4">添加事件</h3>
        <div className="space-y-3">
          <input
            autoFocus
            className="input"
            placeholder="事件标题（如：朋友聚餐）"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <textarea
            className="input min-h-[60px] resize-none"
            placeholder="备注（可选）"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-gray-500">开始时间</label>
              <input
                type="datetime-local"
                className="input mt-1"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
              />
            </div>
            <div>
              <label className="text-xs text-gray-500">结束时间（可选）</label>
              <input
                type="datetime-local"
                className="input mt-1"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
              />
            </div>
          </div>
          <div>
            <label className="text-xs text-gray-500">视角</label>
            <div className="grid grid-cols-3 gap-2 mt-1">
              {EVENT_SCOPES.map((s) => (
                <button
                  key={s}
                  onClick={() => setScope(s)}
                  className={`py-2 rounded-lg text-xs border ${
                    scope === s ? 'border-primary-500 bg-primary-50 text-primary-600' : 'border-gray-200'
                  }`}
                >
                  {eventScopeMeta[s].emoji} {eventScopeMeta[s].label}
                </button>
              ))}
            </div>
          </div>
          <input
            className="input"
            placeholder="地点（可选）"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          />
          <input
            className="input"
            placeholder="参与人物（用逗号分隔，可选）"
            value={attendeesText}
            onChange={(e) => setAttendeesText(e.target.value)}
          />
          <div>
            <label className="text-xs text-gray-500">颜色标识</label>
            <div className="flex gap-2 mt-1 flex-wrap">
              {MANUAL_EVENT_COLORS.map((c) => (
                <button
                  key={c}
                  onClick={() => setColor(c)}
                  className={`w-7 h-7 rounded-full flex items-center justify-center border-2 ${
                    color === c ? 'border-gray-800 scale-110' : 'border-transparent'
                  } transition-transform`}
                  title={manualEventColorMeta[c].label}
                >
                  <span className={`w-4 h-4 rounded-full ${manualEventColorMeta[c].dot}`} />
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="flex gap-2 mt-5">
          <button onClick={onClose} className="btn-secondary flex-1">取消</button>
          <button onClick={submit} disabled={loading} className="btn-primary flex-1 disabled:opacity-50">
            {loading ? '创建中...' : '创建'}
          </button>
        </div>
      </div>
    </div>
  )
}

/**
 * EV-03 事件详情接口
 *
 * 与后端 GET /manual-events/:id/detail 响应对齐。
 * 字段根据事件类型（manual/task/reminder）有所不同。
 */
interface EventDetail {
  id: string
  type: string
  title: string
  time: string
  scope: 'work' | 'life' | 'finance'
  description?: string | null
  location?: string | null
  attendees?: string[]
  color?: string
  priority?: string
  important?: boolean
  progress?: number
  level?: string
  repeat?: string
  countdown: number
  relatedPeople: string[]
  checklist: Array<{ text: string; optional?: boolean }>
}

/**
 * 将秒数倒计时转为人类可读字符串
 * - 正数：还有 X天 X小时 / X小时 X分钟 / X分钟
 * - 0 或负数：已开始 / 已结束
 */
function formatCountdown(seconds: number): { text: string; status: 'upcoming' | 'ongoing' | 'ended' } {
  if (seconds < -3600) {
    return { text: '已结束', status: 'ended' }
  }
  if (seconds <= 0) {
    return { text: '正在进行', status: 'ongoing' }
  }
  const days = Math.floor(seconds / 86400)
  const hours = Math.floor((seconds % 86400) / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)
  if (days > 0) {
    return { text: `还有 ${days} 天 ${hours} 小时`, status: 'upcoming' }
  }
  if (hours > 0) {
    return { text: `还有 ${hours} 小时 ${minutes} 分钟`, status: 'upcoming' }
  }
  return { text: `还有 ${minutes} 分钟`, status: 'upcoming' }
}

/** 提醒重复标签中文映射 */
const repeatLabel: Record<string, string> = {
  once: '单次',
  daily: '每天',
  weekly: '每周',
  monthly: '每月',
}

/** 任务优先级中文映射（与 utils.ts 中 priorityMeta 对齐） */
const priorityLabel: Record<string, string> = {
  urgent: '紧急',
  high: '高',
  medium: '中',
  low: '低',
}

/**
 * EV-03 事件详情弹层
 *
 * 打开后查询 GET /manual-events/:id/detail?type=...
 * 展示：标题/倒计时/来源/备注/关联人物/准备清单
 */
function EventDetailModal({
  event,
  onClose,
}: {
  event: HomeData['events'][number]
  onClose: () => void
}) {
  const toast = useToast((s) => s.show)
  const [detail, setDetail] = useState<EventDetail | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)

  useEffect(() => {
    let cancelled = false
    const loadDetail = async () => {
      setLoading(true)
      setError(false)
      try {
        const res = await unwrap<EventDetail>(
          api.get(`/manual-events/${event.id}/detail`, { params: { type: event.type } })
        )
        if (!cancelled) setDetail(res)
      } catch (err) {
        if (!cancelled) {
          setError(true)
          toast((err as Error).message, 'error')
        }
      } finally {
        if (!cancelled) setLoading(false)
      }
    }
    loadDetail()
    return () => {
      cancelled = true
    }
  }, [event.id, event.type])

  const scopeMeta = eventScopeMeta[event.scope] || eventScopeMeta.life
  const typeLabel = event.type === 'manual' ? '手动事件' : event.type === 'task' ? '任务' : '提醒'
  const typeEmoji = event.type === 'manual' ? '📌' : event.type === 'task' ? '✅' : '🔔'

  return (
    <div className="fixed inset-0 z-50 flex items-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/40" />
      <div
        className="relative bg-white w-full max-w-[480px] mx-auto rounded-t-2xl p-5 animate-slide-up max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* 头部：来源标签 + 关闭 */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="text-lg">{typeEmoji}</span>
            <span className="text-xs text-gray-500">{typeLabel}</span>
            <span className={`text-[10px] px-2 py-0.5 rounded-full ${scopeMeta.bg} ${scopeMeta.color}`}>
              {scopeMeta.emoji} {scopeMeta.label}
            </span>
            {event.manual && (
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-50 text-purple-600">
                手动
              </span>
            )}
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-sm">
            ✕
          </button>
        </div>

        {/* 标题 */}
        <h3 className="text-lg font-semibold text-gray-800 mb-1">{event.title}</h3>

        {/* 倒计时 */}
        {detail && (
          <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs mb-3 ${
            formatCountdown(detail.countdown).status === 'ended'
              ? 'bg-gray-100 text-gray-500'
              : formatCountdown(detail.countdown).status === 'ongoing'
                ? 'bg-green-50 text-green-600'
                : 'bg-blue-50 text-blue-600'
          }`}>
            <span>⏰</span>
            <span>{formatCountdown(detail.countdown).text}</span>
            <span className="text-gray-400 ml-1">· {formatTime(detail.time)}</span>
          </div>
        )}

        {loading && (
          <div className="py-8">
            <LoadingState text="加载事件详情..." />
          </div>
        )}

        {error && (
          <div className="py-6">
            <ErrorState onRetry={() => {
              // 触发重新加载：通过临时切换 event 引用
              setLoading(true)
              setError(false)
              setTimeout(() => {
                api.get(`/manual-events/${event.id}/detail`, { params: { type: event.type } })
                  .then((res) => {
                    const d = (res as { data: EventDetail }).data
                    setDetail(d)
                  })
                  .catch((err) => {
                    setError(true)
                    toast((err as Error).message, 'error')
                  })
                  .finally(() => setLoading(false))
              }, 50)
            }} />
          </div>
        )}

        {detail && !loading && !error && (
          <div className="space-y-3 text-sm">
            {/* 备注 */}
            {detail.description && (
              <div>
                <div className="text-xs text-gray-500 mb-1">备注</div>
                <div className="text-gray-700 bg-gray-50 rounded-lg p-2 whitespace-pre-wrap">
                  {detail.description}
                </div>
              </div>
            )}

            {/* 地点（仅 manual） */}
            {detail.location && (
              <div className="flex items-center gap-2 text-gray-600">
                <MapPin size={14} className="text-gray-400" />
                <span>{detail.location}</span>
              </div>
            )}

            {/* 任务属性 */}
            {detail.type === 'task' && (
              <div className="flex flex-wrap gap-2">
                {detail.priority && (
                  <span className="text-[11px] px-2 py-0.5 rounded bg-gray-50 text-gray-600">
                    优先级：{priorityLabel[detail.priority] || detail.priority}
                  </span>
                )}
                {detail.important && (
                  <span className="text-[11px] px-2 py-0.5 rounded bg-rose-50 text-rose-600">
                    ⭐ 重要
                  </span>
                )}
                {typeof detail.progress === 'number' && (
                  <span className="text-[11px] px-2 py-0.5 rounded bg-blue-50 text-blue-600">
                    进度：{detail.progress}%
                  </span>
                )}
              </div>
            )}

            {/* 提醒属性 */}
            {detail.type === 'reminder' && (
              <div className="flex flex-wrap gap-2">
                {detail.level && (
                  <span className="text-[11px] px-2 py-0.5 rounded bg-amber-50 text-amber-600">
                    等级：{detail.level}
                  </span>
                )}
                {detail.repeat && (
                  <span className="text-[11px] px-2 py-0.5 rounded bg-gray-50 text-gray-600">
                    重复：{repeatLabel[detail.repeat] || detail.repeat}
                  </span>
                )}
              </div>
            )}

            {/* 关联人物 */}
            {detail.relatedPeople.length > 0 && (
              <div>
                <div className="text-xs text-gray-500 mb-1">关联人物</div>
                <div className="flex flex-wrap gap-1">
                  {detail.relatedPeople.map((p, i) => (
                    <span
                      key={`${p}-${i}`}
                      className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-600"
                    >
                      <Users size={10} />
                      {p}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* 准备清单（重要紧急任务） */}
            {detail.checklist.length > 0 && (
              <div>
                <div className="text-xs text-gray-500 mb-1">📋 准备清单</div>
                <div className="space-y-1">
                  {detail.checklist.map((item, i) => (
                    <div
                      key={`${item.text}-${i}`}
                      className={`flex items-center gap-2 text-sm ${
                        item.optional ? 'text-gray-400' : 'text-gray-700'
                      }`}
                    >
                      <span className="w-4 h-4 rounded border border-gray-300 flex-shrink-0" />
                      <span>{item.text}</span>
                      {item.optional && (
                        <span className="text-[10px] text-gray-400">（可选）</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 来源信息 */}
            <div className="pt-2 border-t border-gray-100 text-[11px] text-gray-400">
              事件来源：{typeLabel} · ID {detail.id.slice(-8)}
            </div>
          </div>
        )}

        <div className="flex gap-2 mt-5">
          <button onClick={onClose} className="btn-primary w-full">关闭</button>
        </div>
      </div>
    </div>
  )
}
