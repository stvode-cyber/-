import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuthStore } from '../stores/auth'
import { useToast } from '../components/Toast'

/**
 * 登录 / 注册页
 *
 * 功能：
 * 1. 登录 / 注册模式切换（默认登录）
 * 2. 表单校验：用户名 + 密码必填，注册时密码至少 6 位
 * 3. 演示账号一键登录：demo / admin，点击直接登录无需手动填表
 * 4. 管理后台入口（底部链接）
 */
export default function LoginPage() {
  const { login, register } = useAuthStore()
  const toast = useToast((s) => s.show)
  const navigate = useNavigate()

  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [nickname, setNickname] = useState('')
  const [loading, setLoading] = useState(false)

  /** 表单提交：登录或注册 */
  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!username || !password) {
      toast('请输入用户名和密码', 'error')
      return
    }
    if (mode === 'register' && password.length < 6) {
      toast('密码至少 6 位', 'error')
      return
    }
    setLoading(true)
    try {
      if (mode === 'login') {
        await login(username, password)
        toast('登录成功', 'success')
        navigate('/')
      } else {
        await register(username, password, nickname)
        toast('注册成功', 'success')
        navigate('/')
      }
    } catch (err) {
      toast((err as Error).message, 'error')
    } finally {
      setLoading(false)
    }
  }

  /** 演示账号一键登录：直接调用 login，无需手动填表点按钮 */
  const quickLogin = async (u: string, p: string) => {
    if (loading) return
    setLoading(true)
    try {
      await login(u, p)
      toast('登录成功', 'success')
      navigate('/')
    } catch (err) {
      toast((err as Error).message, 'error')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="app-shell flex flex-col items-center justify-center px-6 min-h-screen bg-gradient-to-b from-primary-50 to-white">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 mx-auto rounded-3xl bg-primary-600 flex items-center justify-center text-white text-4xl font-bold shadow-lg shadow-primary-200">
            小
          </div>
          <h1 className="mt-4 text-2xl font-bold text-gray-800">AI小助</h1>
          <p className="mt-1 text-sm text-gray-500">你的全能个人助理</p>
        </div>

        <form onSubmit={onSubmit} className="space-y-4">
          <div>
            <label className="block text-sm text-gray-600 mb-1">用户名</label>
            <input
              className="input"
              placeholder="请输入用户名"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoComplete="username"
            />
          </div>
          {mode === 'register' && (
            <div>
              <label className="block text-sm text-gray-600 mb-1">昵称（选填）</label>
              <input
                className="input"
                placeholder="给自己起个昵称"
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
              />
            </div>
          )}
          <div>
            <label className="block text-sm text-gray-600 mb-1">密码</label>
            <input
              className="input"
              type="password"
              placeholder="请输入密码（至少6位）"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn-primary w-full disabled:opacity-60"
          >
            {loading ? '处理中...' : mode === 'login' ? '登录' : '注册'}
          </button>
        </form>

        <div className="mt-4 text-center text-sm text-gray-500">
          {mode === 'login' ? (
            <>
              还没有账号？
              <button
                className="text-primary-600 ml-1 font-medium"
                onClick={() => setMode('register')}
              >
                去注册
              </button>
            </>
          ) : (
            <>
              已有账号？
              <button
                className="text-primary-600 ml-1 font-medium"
                onClick={() => setMode('login')}
              >
                去登录
              </button>
            </>
          )}
        </div>

        {/* 快速登录演示账号（一键登录） */}
        <div className="mt-8 pt-6 border-t border-gray-100">
          <p className="text-xs text-gray-400 mb-2 text-center">一键体验演示账号</p>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => quickLogin('demo', '123456')}
              disabled={loading}
              className="btn-secondary text-xs disabled:opacity-50"
            >
              演示用户 demo
            </button>
            <button
              type="button"
              onClick={() => quickLogin('admin', 'admin123')}
              disabled={loading}
              className="btn-secondary text-xs disabled:opacity-50"
            >
              管理员 admin
            </button>
          </div>
        </div>

        <div className="mt-6 text-center">
          <Link to="/admin" className="text-xs text-gray-400 hover:text-gray-600">
            管理后台入口 →
          </Link>
        </div>
      </div>
    </div>
  )
}
