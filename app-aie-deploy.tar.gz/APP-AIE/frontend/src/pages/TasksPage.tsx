import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Plus, Check, Trash2, ChevronDown, ChevronRight, Edit3 } from 'lucide-react'
import Header from '../components/Header'
import { LoadingState, ErrorState, EmptyState } from '../components/StateView'
import { api, unwrap } from '../lib/api'
import { useToast } from '../components/Toast'
import { formatDateTime, priorityMeta } from '../lib/utils'
import { communityCategoryMeta } from '../lib/constants'

interface Task {
  id: string
  title: string
  description?: string
  status: string
  priority: string
  progress: number
  dueDate?: string | null
  category?: string
  important: boolean
  createdAt: string
}

/**
 * 任务日程页
 *
 * 功能：
 * 1. Tab 切换：全部 / 待办 / 已完成
 * 2. 点击任务展开详情：可调整进度（0-100% 滑块）、查看描述、截止时间
 * 3. 列表项支持：完成 / 取消完成 / 删除
 * 4. 新建任务（底部弹层）
 */
export default function TasksPage() {
  const toast = useToast((s) => s.show)
  const [tasks, setTasks] = useState<Task[]>([])
  const [filter, setFilter] = useState<'all' | 'todo' | 'done'>('all')
  const [showAdd, setShowAdd] = useState(false)
  const [expandedId, setExpandedId] = useState<string | null>(null)
  // 编辑中的进度值（实时更新滑块，但失焦后才提交）
  const [editProgress, setEditProgress] = useState<number | null>(null)
  const [searchParams, setSearchParams] = useSearchParams()
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)

  useEffect(() => {
    load()
    // 来自 HomePage 快捷入口 ?new=1 → 自动打开新增弹层
    if (searchParams.get('new') === '1') {
      setShowAdd(true)
      searchParams.delete('new')
      setSearchParams(searchParams, { replace: true })
    }
  }, [filter])

  const load = async () => {
    setLoading(true)
    setError(false)
    try {
      const query = filter === 'all' ? '' : `?status=${filter}`
      const list = await unwrap<Task[]>(api.get(`/work/tasks${query}`))
      setTasks(list)
    } catch (err) {
      setError(true)
      toast((err as Error).message, 'error')
    } finally {
      setLoading(false)
    }
  }

  const toggleDone = async (t: Task) => {
    try {
      if (t.status === 'done') {
        await unwrap(api.patch(`/work/tasks/${t.id}`, { status: 'todo', progress: t.progress || 0 }))
      } else {
        await unwrap(api.post(`/work/tasks/${t.id}/done`))
      }
      load()
    } catch (err) {
      toast((err as Error).message, 'error')
    }
  }

  const remove = async (id: string) => {
    try {
      await unwrap(api.delete(`/work/tasks/${id}`))
      toast('已删除', 'success')
      load()
    } catch (err) {
      toast((err as Error).message, 'error')
    }
  }

  /** 展开任务详情时，初始化进度编辑值 */
  const toggleExpand = (t: Task) => {
    if (expandedId === t.id) {
      setExpandedId(null)
      setEditProgress(null)
    } else {
      setExpandedId(t.id)
      setEditProgress(t.progress)
    }
  }

  /** 保存进度（滑块松手时触发） */
  const saveProgress = async (t: Task, progress: number) => {
    try {
      await unwrap(api.patch(`/work/tasks/${t.id}`, { progress }))
      toast(`进度已更新至 ${progress}%`, 'success')
      load()
    } catch (err) {
      toast((err as Error).message, 'error')
      setEditProgress(t.progress) // 回滚
    }
  }

  const tabs = [
    { key: 'all', label: '全部' },
    { key: 'todo', label: '待办' },
    { key: 'done', label: '已完成' },
  ] as const

  return (
    <div className="app-shell">
      <Header
        title="任务日程"
        right={
          <button onClick={() => setShowAdd(true)} className="p-2 text-primary-600">
            <Plus size={20} />
          </button>
        }
      />
      <div className="sticky top-12 bg-white z-10 border-b border-gray-100">
        <div className="flex">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setFilter(t.key)}
              className={`flex-1 py-3 text-sm border-b-2 ${
                filter === t.key
                  ? 'border-primary-500 text-primary-600 font-medium'
                  : 'border-transparent text-gray-500'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="px-3 py-3 space-y-2">
        {loading ? (
          <LoadingState skeleton count={3} />
        ) : error ? (
          <ErrorState onRetry={load} />
        ) : tasks.length === 0 ? (
          <EmptyState icon="📝" text="暂无任务" hint="点击右上角 + 创建" />
        ) : (
          tasks.map((t) => {
            const meta = priorityMeta[t.priority] || priorityMeta.medium
            const done = t.status === 'done'
            const expanded = expandedId === t.id
            return (
              <div key={t.id} className="card group">
                <div className="flex items-start gap-3">
                  <button
                    onClick={() => toggleDone(t)}
                    className={`mt-0.5 w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                      done ? 'bg-green-500 border-green-500' : 'border-gray-300'
                    }`}
                  >
                    {done && <Check size={12} className="text-white" />}
                  </button>
                  <div
                    className="flex-1 min-w-0 cursor-pointer"
                    onClick={() => toggleExpand(t)}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-gray-300">
                        {expanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                      </span>
                      <span className={`text-sm ${done ? 'line-through text-gray-400' : 'text-gray-800'}`}>
                        {t.important && '🔴 '}{t.title}
                      </span>
                      <span className={`badge ${meta.bg} ${meta.color}`}>{meta.label}</span>
                    </div>
                    {!expanded && t.description && (
                      <div className="text-xs text-gray-500 mt-1 truncate ml-5">{t.description}</div>
                    )}
                    <div className="flex items-center gap-3 mt-2 text-xs text-gray-400 ml-5">
                      {t.dueDate && <span>📅 {formatDateTime(t.dueDate)}</span>}
                      <span>📊 {t.progress}%</span>
                      <span className={`badge ${categoryBadge(t.category)}`}>
                        {categoryLabel(t.category)}
                      </span>
                    </div>
                    {/* 进度条（折叠态） */}
                    {!expanded && (
                      <div className="mt-2 h-1 bg-gray-100 rounded-full overflow-hidden ml-5">
                        <div
                          className="h-full bg-primary-500 transition-all"
                          style={{ width: `${t.progress}%` }}
                        />
                      </div>
                    )}
                  </div>
                  <button
                    onClick={() => remove(t.id)}
                    className="opacity-0 group-hover:opacity-100 p-1 text-gray-300 hover:text-red-500 transition-opacity"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>

                {/* 展开详情：进度调整 + 描述 */}
                {expanded && (
                  <div className="mt-3 pt-3 border-t border-gray-50 ml-8 space-y-3">
                    {/* 进度滑块 */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-xs text-gray-500 flex items-center gap-1">
                          <Edit3 size={12} /> 进度
                        </label>
                        <span className={`text-xs font-medium ${editProgress === 100 ? 'text-green-500' : 'text-primary-600'}`}>
                          {editProgress ?? t.progress}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={100}
                        step={5}
                        value={editProgress ?? t.progress}
                        onChange={(e) => setEditProgress(Number(e.target.value))}
                        onMouseUp={(e) => saveProgress(t, Number((e.target as HTMLInputElement).value))}
                        onTouchEnd={(e) => saveProgress(t, Number((e.target as HTMLInputElement).value))}
                        className="w-full accent-primary-600"
                        disabled={done}
                      />
                      <div className="flex justify-between text-[10px] text-gray-400 mt-0.5">
                        <span>0%</span>
                        <span>25%</span>
                        <span>50%</span>
                        <span>75%</span>
                        <span>100%</span>
                      </div>
                    </div>

                    {/* 描述 */}
                    {t.description ? (
                      <div>
                        <div className="text-xs text-gray-500 mb-1">描述</div>
                        <div className="text-sm text-gray-700 bg-gray-50 rounded-lg p-2">
                          {t.description}
                        </div>
                      </div>
                    ) : (
                      <div className="text-xs text-gray-400">无描述</div>
                    )}

                    {/* 创建时间 */}
                    <div className="text-xs text-gray-400">
                      创建于 {formatDateTime(t.createdAt)}
                    </div>
                  </div>
                )}
              </div>
            )
          })
        )}
      </div>

      {showAdd && <AddTaskModal onClose={() => setShowAdd(false)} onAdded={load} />}
    </div>
  )
}

function AddTaskModal({ onClose, onAdded }: { onClose: () => void; onAdded: () => void }) {
  const toast = useToast((s) => s.show)
  const [title, setTitle] = useState('')
  const [priority, setPriority] = useState<'low' | 'medium' | 'high' | 'urgent'>('medium')
  const [dueDate, setDueDate] = useState('')
  const [category, setCategory] = useState('work')
  const [important, setImportant] = useState(false)
  const [loading, setLoading] = useState(false)

  const submit = async () => {
    if (!title.trim()) {
      toast('请输入任务标题', 'error')
      return
    }
    setLoading(true)
    try {
      await unwrap(api.post('/work/tasks', {
        title,
        priority,
        dueDate: dueDate || undefined,
        category,
        important,
      }))
      toast('任务已创建', 'success')
      onAdded()
      onClose()
    } catch (err) {
      toast((err as Error).message, 'error')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/40" />
      <div
        className="relative bg-white w-full max-w-[480px] mx-auto rounded-t-2xl p-5 animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="text-lg font-semibold mb-4">新建任务</h3>
        <div className="space-y-3">
          <input
            autoFocus
            className="input"
            placeholder="任务标题"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <div>
            <label className="text-xs text-gray-500">优先级</label>
            <div className="flex gap-2 mt-1">
              {(['low', 'medium', 'high', 'urgent'] as const).map((p) => (
                <button
                  key={p}
                  onClick={() => setPriority(p)}
                  className={`flex-1 py-2 rounded-lg text-xs border ${
                    priority === p ? 'border-primary-500 bg-primary-50 text-primary-600' : 'border-gray-200 text-gray-500'
                  }`}
                >
                  {priorityMeta[p].label}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-xs text-gray-500">截止时间</label>
            <input
              type="datetime-local"
              className="input mt-1"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
            />
          </div>
          <div>
            <label className="text-xs text-gray-500">分类</label>
            <div className="flex gap-2 mt-1">
              {['work', 'life', 'finance'].map((c) => (
                <button
                  key={c}
                  onClick={() => setCategory(c)}
                  className={`flex-1 py-2 rounded-lg text-xs border ${
                    category === c ? 'border-primary-500 bg-primary-50 text-primary-600' : 'border-gray-200 text-gray-500'
                  }`}
                >
                  {c === 'work' ? '工作' : c === 'life' ? '生活' : '财务'}
                </button>
              ))}
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={important}
              onChange={(e) => setImportant(e.target.checked)}
              className="w-4 h-4 accent-primary-600"
            />
            标记为重要事项
          </label>
        </div>
        <div className="flex gap-2 mt-5">
          <button onClick={onClose} className="btn-secondary flex-1">取消</button>
          <button onClick={submit} disabled={loading} className="btn-primary flex-1 disabled:opacity-50">
            {loading ? '创建中...' : '创建'}
          </button>
        </div>
      </div>
    </div>
  )
}

/** 任务分类 → 中文标签（复用 communityCategoryMeta） */
function categoryLabel(cat?: string): string {
  return communityCategoryMeta[cat || '']?.label || '其他'
}

/** 任务分类 → 徽章配色（复用 communityCategoryMeta） */
function categoryBadge(cat?: string): string {
  return communityCategoryMeta[cat || '']?.color || 'bg-gray-100 text-gray-600'
}
