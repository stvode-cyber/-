import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api, unwrap } from '../lib/api'
import { useAuthStore } from '../stores/auth'
import { useToast } from '../components/Toast'
import { toneMeta } from '../lib/utils'

/**
 * 冷启动引导页
 *
 * 三步引导，采集用户画像用于个性化推荐：
 * 1. 本周主目标（primaryGoal，必填）
 * 2. AI 对话语气偏好（preferredTone，9 选 1，默认 gentle）
 * 3. 最爱吃的食物（favoriteFood，选填，可跳过）
 *
 * 提交：POST /auth/onboarding，成功后刷新用户信息并跳转主页
 */
export default function OnboardingPage() {
  const navigate = useNavigate()
  const { refreshUser, setOnboarded } = useAuthStore()
  const toast = useToast((s) => s.show)

  const [step, setStep] = useState(0)
  const [primaryGoal, setPrimaryGoal] = useState('')
  const [preferredTone, setPreferredTone] = useState('gentle')
  const [favoriteFood, setFavoriteFood] = useState('')
  const [loading, setLoading] = useState(false)

  const steps = [
    {
      title: '本周最想搞定的事？',
      subtitle: '让我更懂你，给你更精准的建议',
      input: (
        <input
          autoFocus
          className="input text-lg"
          placeholder="比如：完成产品V3上线"
          value={primaryGoal}
          onChange={(e) => setPrimaryGoal(e.target.value)}
        />
      ),
      canNext: primaryGoal.trim().length > 0,
    },
    {
      title: '更喜欢哪种语气？',
      subtitle: '可以随时在设置里修改',
      input: (
        <div className="grid grid-cols-3 gap-2">
          {Object.entries(toneMeta).slice(0, 9).map(([key, meta]) => (
            <button
              key={key}
              type="button"
              onClick={() => setPreferredTone(key)}
              className={`p-3 rounded-xl border-2 transition-all ${
                preferredTone === key
                  ? 'border-primary-500 bg-primary-50'
                  : 'border-gray-100 bg-white'
              }`}
            >
              <div className="text-2xl">{meta.emoji}</div>
              <div className="text-xs mt-1 text-gray-700">{meta.label}</div>
            </button>
          ))}
        </div>
      ),
      canNext: true,
    },
    {
      title: '现在最想吃啥？',
      subtitle: '最后一步，帮你定制饮食建议',
      input: (
        <input
          autoFocus
          className="input text-lg"
          placeholder="比如：火锅、轻食、妈妈做的菜"
          value={favoriteFood}
          onChange={(e) => setFavoriteFood(e.target.value)}
        />
      ),
      canNext: true,
    },
  ]

  const current = steps[step]

  const submit = async () => {
    setLoading(true)
    try {
      await unwrap(
        api.post('/auth/onboarding', { primaryGoal, preferredTone, favoriteFood }),
      )
      await refreshUser()
      setOnboarded()
      toast('欢迎来到 AI小助！', 'success')
      navigate('/')
    } catch (err) {
      toast((err as Error).message, 'error')
    } finally {
      setLoading(false)
    }
  }

  const next = () => {
    if (step < steps.length - 1) {
      setStep(step + 1)
    } else {
      submit()
    }
  }

  return (
    <div className="app-shell flex flex-col min-h-screen bg-white px-6 py-12">
      <div className="flex-1 flex flex-col justify-center max-w-sm mx-auto w-full">
        {/* 进度 */}
        <div className="flex gap-1 mb-8">
          {steps.map((_, i) => (
            <div
              key={i}
              className={`h-1 flex-1 rounded-full transition-colors ${
                i <= step ? 'bg-primary-500' : 'bg-gray-200'
              }`}
            />
          ))}
        </div>

        <h2 className="text-2xl font-bold text-gray-800">{current.title}</h2>
        <p className="mt-2 text-sm text-gray-500">{current.subtitle}</p>

        <div className="mt-8">{current.input}</div>
      </div>

      <div className="max-w-sm mx-auto w-full space-y-2">
        <button
          onClick={next}
          disabled={!current.canNext || loading}
          className="btn-primary w-full disabled:opacity-50"
        >
          {loading ? '保存中...' : step < steps.length - 1 ? '下一步' : '开始体验'}
        </button>
        <div className="flex gap-2">
          {step > 0 && (
            <button
              onClick={() => setStep(step - 1)}
              className="btn-secondary flex-1"
            >
              上一步
            </button>
          )}
          {/* 最后一步（最爱吃的食物）为选填，允许跳过 */}
          {step === steps.length - 1 && (
            <button
              onClick={submit}
              disabled={loading}
              className="btn-secondary flex-1"
            >
              跳过
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
