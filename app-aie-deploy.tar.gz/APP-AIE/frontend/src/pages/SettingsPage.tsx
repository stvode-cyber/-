import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Check, Loader2, Trash2, Info, ChevronRight } from 'lucide-react'
import Header from '../components/Header'
import { api, unwrap } from '../lib/api'
import { useToast } from '../components/Toast'
import { useAuthStore, type UserInfo } from '../stores/auth'
import { toneMeta } from '../lib/utils'
import { useConfirm } from '../components/ConfirmDialog'

/**
 * 设置页
 *
 * 四大区域：
 * 1. 个人资料：昵称、头像 emoji、本周目标（调用 PATCH /auth/me）
 * 2. AI 语气偏好：9 种模式切换（实时保存）
 * 3. 关于：版本信息、用户协议、隐私政策
 * 4. 清除缓存：清 localStorage 业务数据（保留登录态）
 *
 * 接口：
 * - PATCH /auth/me  更新个人资料
 */

/** 头像 emoji 候选列表 */
const avatarOptions = ['👤', '🦁', '🐯', '🦊', '🐼', '🦊', '🐨', '🦉', '🐲', '🌸', '🍀', '⭐']

export default function SettingsPage() {
  const navigate = useNavigate()
  const toast = useToast((s) => s.show)
  const confirm = useConfirm()
  const { user, updateUser, logout } = useAuthStore()

  const [nickname, setNickname] = useState(user?.nickname || '')
  const [avatar, setAvatar] = useState(user?.avatar || '👤')
  const [primaryGoal, setPrimaryGoal] = useState(user?.primaryGoal || '')
  const [savingProfile, setSavingProfile] = useState(false)
  const [savingTone, setSavingTone] = useState(false)

  /** 保存个人资料（昵称 / 头像 / 本周目标） */
  const saveProfile = async () => {
    if (!nickname.trim()) {
      toast('昵称不能为空', 'error')
      return
    }
    setSavingProfile(true)
    try {
      const updated = await unwrap<UserInfo>(
        api.patch('/auth/me', {
          nickname: nickname.trim(),
          avatar,
          primaryGoal: primaryGoal.trim() || null,
        }),
      )
      updateUser(updated)
      toast('资料已保存', 'success')
    } catch (err) {
      toast((err as Error).message, 'error')
    } finally {
      setSavingProfile(false)
    }
  }

  /** 切换语气偏好（实时保存） */
  const changeTone = async (tone: string) => {
    if (tone === user?.preferredTone) return
    setSavingTone(true)
    // 乐观更新
    updateUser({ preferredTone: tone })
    try {
      const updated = await unwrap<UserInfo>(api.patch('/auth/me', { preferredTone: tone }))
      updateUser(updated)
      toast('语气偏好已切换', 'success')
    } catch (err) {
      // 回滚
      updateUser({ preferredTone: user?.preferredTone || 'gentle' })
      toast((err as Error).message, 'error')
    } finally {
      setSavingTone(false)
    }
  }

  /** 清除业务缓存（保留登录态） */
  const clearCache = async () => {
    if (!(await confirm({
      title: '清除本地缓存',
      message: '确认清除本地缓存？登录态会保留，但页面数据需重新加载。',
      confirmText: '清除',
      danger: true,
    }))) return
    const token = localStorage.getItem('aie_token')
    const userStr = localStorage.getItem('aie_user')
    localStorage.clear()
    if (token) localStorage.setItem('aie_token', token)
    if (userStr) localStorage.setItem('aie_user', userStr)
    toast('缓存已清除', 'success')
    setTimeout(() => window.location.reload(), 500)
  }

  const tones = Object.entries(toneMeta)

  return (
    <div className="app-shell">
      <Header title="设置" />

      <div className="px-3 py-4 space-y-4">
        {/* 1. 个人资料 */}
        <section className="card">
          <h2 className="text-sm font-medium text-gray-800 mb-3">个人资料</h2>

          {/* 头像选择 */}
          <div className="mb-4">
            <div className="text-xs text-gray-500 mb-2">头像</div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-primary-100 flex items-center justify-center text-2xl">
                {avatar}
              </div>
              <div className="flex flex-wrap gap-1.5">
                {avatarOptions.map((a) => (
                  <button
                    key={a}
                    onClick={() => setAvatar(a)}
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-lg ${
                      avatar === a ? 'bg-primary-100 ring-2 ring-primary-500' : 'bg-gray-100'
                    }`}
                  >
                    {a}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 昵称 */}
          <div className="mb-4">
            <label className="text-xs text-gray-500 block mb-1.5">昵称</label>
            <input
              type="text"
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              maxLength={20}
              placeholder="请输入昵称"
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:border-primary-500 focus:outline-none"
            />
          </div>

          {/* 本周目标 */}
          <div className="mb-4">
            <label className="text-xs text-gray-500 block mb-1.5">本周目标</label>
            <input
              type="text"
              value={primaryGoal}
              onChange={(e) => setPrimaryGoal(e.target.value)}
              maxLength={50}
              placeholder="本周最想搞定的事"
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:border-primary-500 focus:outline-none"
            />
          </div>

          <button
            onClick={saveProfile}
            disabled={savingProfile}
            className="btn-primary w-full py-2 text-sm flex items-center justify-center gap-1 disabled:opacity-50"
          >
            {savingProfile ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />}
            保存资料
          </button>
        </section>

        {/* 2. AI 语气偏好 */}
        <section className="card">
          <h2 className="text-sm font-medium text-gray-800 mb-1">AI 语气偏好</h2>
          <p className="text-xs text-gray-400 mb-3">选择 AI 小助与你的对话风格</p>
          <div className="grid grid-cols-3 gap-2">
            {tones.map(([key, meta]) => {
              const active = user?.preferredTone === key
              return (
                <button
                  key={key}
                  onClick={() => changeTone(key)}
                  disabled={savingTone}
                  className={`flex flex-col items-center gap-1 py-3 rounded-lg border transition-colors ${
                    active
                      ? 'border-primary-500 bg-primary-50 text-primary-600'
                      : 'border-gray-200 text-gray-600 hover:bg-gray-50'
                  } disabled:opacity-50`}
                >
                  <span className="text-xl">{meta.emoji}</span>
                  <span className="text-xs">{meta.label}</span>
                  {active && <Check size={12} className="text-primary-500" />}
                </button>
              )
            })}
          </div>
          {savingTone && (
            <div className="mt-2 text-center text-xs text-gray-400 flex items-center justify-center gap-1">
              <Loader2 size={12} className="animate-spin" /> 保存中...
            </div>
          )}
        </section>

        {/* 3. 关于 */}
        <section className="card">
          <h2 className="text-sm font-medium text-gray-800 mb-3">关于</h2>
          <div className="space-y-1">
            <div className="flex items-center justify-between py-2.5 border-b border-gray-50">
              <span className="text-sm text-gray-600 flex items-center gap-2">
                <Info size={16} className="text-gray-400" /> 当前版本
              </span>
              <span className="text-xs text-gray-400">MVP v1.0.0</span>
            </div>
            <button
              onClick={() => toast('用户协议：MVP 阶段待完善', 'info')}
              className="w-full flex items-center justify-between py-2.5 border-b border-gray-50 hover:bg-gray-50 -mx-1 px-1 rounded"
            >
              <span className="text-sm text-gray-600">用户协议</span>
              <ChevronRight size={16} className="text-gray-300" />
            </button>
            <button
              onClick={() => toast('隐私政策：MVP 阶段待完善', 'info')}
              className="w-full flex items-center justify-between py-2.5 hover:bg-gray-50 -mx-1 px-1 rounded"
            >
              <span className="text-sm text-gray-600">隐私政策</span>
              <ChevronRight size={16} className="text-gray-300" />
            </button>
          </div>
        </section>

        {/* 4. 清除缓存 */}
        <section className="card">
          <button
            onClick={clearCache}
            className="w-full flex items-center justify-between py-3 hover:bg-gray-50 -mx-1 px-1 rounded"
          >
            <span className="text-sm text-gray-600 flex items-center gap-2">
              <Trash2 size={16} className="text-gray-400" /> 清除本地缓存
            </span>
            <ChevronRight size={16} className="text-gray-300" />
          </button>
        </section>

        {/* 退出登录 */}
        <button
          onClick={async () => {
            if (await confirm({
              title: '退出登录',
              message: '确认退出当前账号？',
              confirmText: '退出',
              danger: true,
            })) logout()
          }}
          className="card w-full flex items-center justify-center gap-2 py-3 text-red-500 hover:bg-red-50"
        >
          退出登录
        </button>

        <div className="text-center text-xs text-gray-300 py-2">
          AI小助 MVP v1.0.0
        </div>
      </div>
    </div>
  )
}
