import axios from 'axios'

/**
 * HTTP 客户端
 *
 * - baseURL：/api/v1（开发环境由 vite proxy 转发到后端）
 * - 超时：15s
 *
 * 拦截器：
 * - 请求拦截：自动注入 Authorization: Bearer <token>
 * - 响应拦截：
 *   1. 后端统一响应格式 { code, data, message }
 *      code === 200 时直接返回 data；非 200 抛出 Error(message)
 *   2. code === 401 或 HTTP 401：清缓存并跳转 /login
 *
 * unwrap<T>：泛型辅助函数，从 Promise<{ data: T }> 中提取 data
 */
const baseURL = '/api/v1'

export const api = axios.create({
  baseURL,
  timeout: 15000,
})

// 请求拦截：自动带 token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('aie_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// 响应拦截：统一处理 code/message
api.interceptors.response.use(
  (response) => {
    const data = response.data
    if (data && typeof data === 'object' && 'code' in data) {
      if (data.code === 200) {
        return data
      }
      // 401 跳登录
      if (data.code === 401) {
        localStorage.removeItem('aie_token')
        localStorage.removeItem('aie_user')
        if (!window.location.pathname.startsWith('/login')) {
          window.location.href = '/login'
        }
      }
      return Promise.reject(new Error(data.message || '请求失败'))
    }
    return data
  },
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('aie_token')
      localStorage.removeItem('aie_user')
      if (!window.location.pathname.startsWith('/login')) {
        window.location.href = '/login'
      }
    }
    const msg = error.response?.data?.message || error.message || '网络异常'
    return Promise.reject(new Error(msg))
  },
)

// 提取 data
export function unwrap<T>(p: Promise<{ data: T }>): Promise<T> {
  return p.then((r) => r.data)
}
