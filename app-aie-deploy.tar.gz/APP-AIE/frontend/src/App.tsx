import { Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { lazy, Suspense, useEffect } from 'react'
import { useAuthStore } from './stores/auth'
import Layout from './components/Layout'
import LoginPage from './pages/LoginPage'
import OnboardingPage from './pages/OnboardingPage'
import HomePage from './pages/HomePage'
import ChatPage from './pages/ChatPage'
import CommunityPage from './pages/CommunityPage'
import ProfilePage from './pages/ProfilePage'

// 路由懒加载：非首屏页面按需加载，降低主 bundle 体积
const WalletPage = lazy(() => import('./pages/WalletPage'))
const WalletRechargePage = lazy(() => import('./pages/WalletRechargePage'))
const WalletTransactionsPage = lazy(() => import('./pages/WalletTransactionsPage'))
const TasksPage = lazy(() => import('./pages/TasksPage'))
const DietPage = lazy(() => import('./pages/DietPage'))
const SleepPage = lazy(() => import('./pages/SleepPage'))
const FragmentsPage = lazy(() => import('./pages/FragmentsPage'))
const VoiceMemoListPage = lazy(() => import('./pages/VoiceMemoListPage'))
const LiveMeetingPage = lazy(() => import('./pages/LiveMeetingPage'))
const VerifyPage = lazy(() => import('./pages/VerifyPage'))
const FinancePage = lazy(() => import('./pages/FinancePage'))
const RemindersPage = lazy(() => import('./pages/RemindersPage'))
const HandoverPage = lazy(() => import('./pages/HandoverPage'))
const SettingsPage = lazy(() => import('./pages/SettingsPage'))
const SearchPage = lazy(() => import('./pages/SearchPage'))

// 管理后台整体懒加载（仅管理员访问）
const AdminLayout = lazy(() => import('./pages/admin/AdminLayout'))
const AdminDashboard = lazy(() => import('./pages/admin/AdminDashboard'))
const AdminUsers = lazy(() => import('./pages/admin/AdminUsers'))
const AdminUserDetail = lazy(() => import('./pages/admin/AdminUserDetail'))
const AdminAuditLogs = lazy(() => import('./pages/admin/AdminAuditLogs'))
const AdminHandovers = lazy(() => import('./pages/admin/AdminHandovers'))
const AdminCommunity = lazy(() => import('./pages/admin/AdminCommunity'))

/** 懒加载路由的加载占位 */
function RouteFallback() {
  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="text-gray-400 animate-pulse">加载中...</div>
    </div>
  )
}

/**
 * 应用根组件 · 路由总入口
 *
 * 路由分三层：
 * 1. 管理后台路由（/admin/*）：独立布局，不走用户态校验
 * 2. 未登录路由：仅放行 /login，其余重定向到 /login
 * 3. 已登录路由：未完成冷启动的强制跳 /onboarding；其余按业务模块分发
 *
 * 业务模块路由组织：
 * - 主 Tab（带 Layout 底部导航）：主页 / 对话 / 社区 / 个人中心
 * - 独立全屏页：钱包、任务、饮食、财务、提醒等
 */
export default function App() {
  const { user, token, loading, init } = useAuthStore()
  const location = useLocation()

  useEffect(() => {
    init()
  }, [init])

  // 管理后台路由独立（不参与用户态校验）
  if (location.pathname.startsWith('/admin')) {
    return (
      <Suspense fallback={<RouteFallback />}>
        <Routes>
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<AdminDashboard />} />
            <Route path="users" element={<AdminUsers />} />
            <Route path="users/:id" element={<AdminUserDetail />} />
            {/* 台账 · 操作日志查看页 */}
            <Route path="audit-logs" element={<AdminAuditLogs />} />
            {/* 交接单 · 跨用户查看页 */}
            <Route path="handovers" element={<AdminHandovers />} />
            {/* 社区内容 · 帖子审核与删除 */}
            <Route path="community" element={<AdminCommunity />} />
          </Route>
        </Routes>
      </Suspense>
    )
  }

  // 初始化中：显示 loading
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-gray-400 animate-pulse">加载中...</div>
      </div>
    )
  }

  // 未登录：仅放行 /login
  if (!token || !user) {
    return (
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    )
  }

  // 未完成冷启动画像：强制跳转 onboarding
  if (!user.onboarded && location.pathname !== '/onboarding') {
    return <Navigate to="/onboarding" replace />
  }

  // 已登录主路由
  return (
    <Suspense fallback={<RouteFallback />}>
      <Routes>
        <Route path="/login" element={<Navigate to="/" replace />} />
        <Route path="/onboarding" element={<OnboardingPage />} />
        {/* 主 Tab（带底部导航 Layout） */}
        <Route element={<Layout />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/chat" element={<ChatPage />} />
          <Route path="/community" element={<CommunityPage />} />
          <Route path="/profile" element={<ProfilePage />} />
        </Route>
        {/* 独立全屏业务页 */}
        <Route path="/wallet" element={<WalletPage />} />
        <Route path="/wallet/recharge" element={<WalletRechargePage />} />
        <Route path="/wallet/transactions" element={<WalletTransactionsPage />} />
        <Route path="/tasks" element={<TasksPage />} />
        <Route path="/diet" element={<DietPage />} />
        <Route path="/sleep" element={<SleepPage />} />
        <Route path="/fragments" element={<FragmentsPage />} />
        <Route path="/voice-memos" element={<VoiceMemoListPage />} />
        <Route path="/live-meeting" element={<LiveMeetingPage />} />
        <Route path="/verify" element={<VerifyPage />} />
        <Route path="/finance" element={<FinancePage />} />
        <Route path="/reminders" element={<RemindersPage />} />
        <Route path="/handover" element={<HandoverPage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/search" element={<SearchPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  )
}
