import { create } from 'zustand'

/**
 * 全局 Toast 通知系统
 *
 * 基于 Zustand 全局状态，任意组件可通过 useToast((s) => s.show) 调用。
 *
 * 使用方式：
 *   const toast = useToast((s) => s.show)
 *   toast('保存成功', 'success')
 *   toast('保存失败', 'error')
 *   toast('提示信息', 'info')
 *
 * 特性：
 * - 自动消失（2.5s 后移除）
 * - 点击可手动关闭
 * - 三种类型：success（绿）/ error（红）/ info（深灰）
 * - 多条 Toast 垂直堆叠，顶部居中显示
 */
interface ToastItem {
  id: number
  message: string
  type: 'success' | 'error' | 'info'
}

interface ToastState {
  toasts: ToastItem[]
  show: (message: string, type?: ToastItem['type']) => void
  remove: (id: number) => void
}

let nextId = 1

export const useToast = create<ToastState>((set) => ({
  toasts: [],
  show: (message, type = 'info') => {
    const id = nextId++
    set((s) => ({ toasts: [...s.toasts, { id, message, type }] }))
    setTimeout(() => {
      set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) }))
    }, 2500)
  },
  remove: (id) => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),
}))

/** Toast 渲染容器：在 Layout 中挂载一次即可全局生效 */
export function Toaster() {
  const { toasts, remove } = useToast()
  if (toasts.length === 0) return null
  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[100] flex flex-col gap-2 pointer-events-none">
      {toasts.map((t) => (
        <div
          key={t.id}
          onClick={() => remove(t.id)}
          className={`px-4 py-2 rounded-lg shadow-lg text-sm text-white animate-slide-up pointer-events-auto cursor-pointer ${
            t.type === 'success'
              ? 'bg-green-500'
              : t.type === 'error'
              ? 'bg-red-500'
              : 'bg-gray-800'
          }`}
        >
          {t.message}
        </div>
      ))}
    </div>
  )
}
