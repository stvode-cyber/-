import { NavLink, useLocation } from 'react-router-dom'
import { Home, MessageCircle, Users, User } from 'lucide-react'

/**
 * 底部导航栏（主 Tab）
 *
 * 4 个 Tab：主页 / 对话 / 社区 / 我的
 * - 主页使用精确匹配（pathname === '/'）
 * - 其余 Tab 使用前缀匹配（pathname.startsWith(to)）
 * - 激活态：图标 + 文字变 primary-600，图标 strokeWidth 加粗
 *
 * 仅在主 Tab 路由（Layout）下渲染，独立全屏页不显示
 */
export default function TabBar() {
  const location = useLocation()

  const tabs = [
    { to: '/', label: '主页', icon: Home },
    { to: '/chat', label: '对话', icon: MessageCircle },
    { to: '/community', label: '社区', icon: Users },
    { to: '/profile', label: '我的', icon: User },
  ]

  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-[480px] mx-auto bg-white border-t border-gray-100 z-40">
      <div className="grid grid-cols-4 h-14">
        {tabs.map(({ to, label, icon: Icon }) => {
          const active = to === '/' ? location.pathname === '/' : location.pathname.startsWith(to)
          return (
            <NavLink
              key={to}
              to={to}
              className="flex flex-col items-center justify-center gap-0.5 transition-colors"
            >
              <Icon
                size={22}
                className={active ? 'text-primary-600' : 'text-gray-400'}
                strokeWidth={active ? 2.4 : 2}
              />
              <span
                className={`text-[10px] ${active ? 'text-primary-600 font-medium' : 'text-gray-400'}`}
              >
                {label}
              </span>
            </NavLink>
          )
        })}
      </div>
    </nav>
  )
}
